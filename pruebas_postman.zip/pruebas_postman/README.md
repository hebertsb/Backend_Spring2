# 🧪 Pruebas Postman - Sistema de Turismo

Esta carpeta contiene todas las pruebas organizadas por funcionalidad para facilitar el testing de la API.

## 📁 Estructura de Carpetas

```
pruebas_postman/
├── 01_autenticacion/          # Login, registro, JWT tokens
├── 02_usuarios/               # CRUD usuarios, perfiles, roles  
├── 03_servicios/              # CRUD servicios, categorías
├── 04_reservas/               # CRUD reservas, visitantes
├── 05_reprogramacion/         # Sistema de reprogramación avanzada
├── 06_tickets_soporte/        # Sistema de tickets y soporte
├── 07_notificaciones/         # Sistema de notificaciones
├── 08_campañas_cupones/       # Marketing y descuentos
├── 09_pagos/                  # Sistema de pagos
└── 10_backups/                # Respaldos y restauración
```

## 🚀 Servidor de Desarrollo

**URL Base:** `http://127.0.0.1:8000/api/`

## 📋 Instrucciones de Uso

1. **Importar colecciones** de Postman desde cada subcarpeta
2. **Configurar environment** con la URL base 
3. **Ejecutar autenticación** primero para obtener tokens
4. **Probar endpoints** siguiendo el orden numérico de carpetas

## 🔑 Datos de Prueba

Los fixtures incluyen datos iniciales para todas las funcionalidades. Ver `condominio/fixtures/datos_iniciales.json`.

## ⚡ Funcionalidades Implementadas

- ✅ **Autenticación JWT** completa
- ✅ **CRUD completo** para todos los modelos
- ✅ **Sistema de reprogramación avanzada** 
- ✅ **Tickets de soporte** con asignación automática
- ✅ **Notificaciones** en tiempo real
- ✅ **Bitácora automática** para auditoría
- ✅ **Backups** con integración Dropbox

---
*Generado automáticamente - No subir a Git*