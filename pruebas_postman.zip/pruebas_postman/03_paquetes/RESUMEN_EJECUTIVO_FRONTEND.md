# 🎯 RESUMEN EJECUTIVO - APIs para Frontend

## ⚡ **DECISIÓN RÁPIDA**

### 🤔 **¿Qué API necesita usar tu frontend?**

| Tu frontend necesita mostrar...                                                       | API correcta         | URL                             |
| ------------------------------------------------------------------------------------- | -------------------- | ------------------------------- |
| **Paquetes completos de vacaciones** (ej: "Full Tour Bolivia" con múltiples destinos) | Paquetes             | `/api/paquetes/`                |
| **Destinos individuales** (ej: "Salar de Uyuni" como actividad separada)              | Servicios            | `/api/servicios/`               |
| **Carousel de ofertas principales**                                                   | Paquetes destacados  | `/api/paquetes/destacados/`     |
| **Búsqueda por precio de experiencias completas**                                     | Paquetes con filtros | `/api/paquetes/?precio_min=200` |
| **Actividades por separado que usuarios pueden combinar**                             | Servicios            | `/api/servicios/?estado=Activo` |

---

## 📦 **PAQUETES TURÍSTICOS - Para Experiencias Completas**

### 🎯 **¿Cuándo usarlos?**

Cuando quieres que los usuarios vean **vacaciones organizadas** que incluyen múltples destinos.

### 📊 **Lo que obtienes:**

- **Nombre:** "Full Tour Bolivia - Experiencia Completa"
- **Duración:** "5 días, 4 noches"
- **Precio:** $850 USD (precio del paquete completo)
- **Incluye:** Salar de Uyuni + Isla del Sol + Tiwanaku
- **Itinerario:** Día por día con horarios
- **Disponibilidad:** Cupos restantes, fechas vigentes

### 🔗 **URLs principales:**

```
GET /api/paquetes/                    → Todos los paquetes
GET /api/paquetes/destacados/         → Para homepage (máx 6)
GET /api/paquetes/disponibles/        → Solo reservables
GET /api/paquetes/1/                  → Detalle completo
GET /api/paquetes/1/itinerario/       → Itinerario día por día
```

### 💡 **Ejemplo de uso:**

```javascript
// Carousel principal de homepage
fetch("/api/paquetes/destacados/")
  .then((response) => response.json())
  .then((paquetes) => {
    paquetes.forEach((paquete) => {
      console.log(
        `${paquete.nombre} - ${paquete.duracion} - $${paquete.precio_base}`
      );
      console.log(`Incluye ${paquete.servicios_incluidos.length} destinos`);
    });
  });
```

---

## 🏕️ **SERVICIOS/DESTINOS - Para Actividades Individuales**

### 🎯 **¿Cuándo usarlos?**

Cuando quieres mostrar **destinos específicos** que se pueden reservar por separado.

### 📊 **Lo que obtienes:**

- **Título:** "Salar de Uyuni"
- **Duración:** "1 día"
- **Precio:** $250 USD (precio individual)
- **Capacidad:** Hasta 8 personas
- **Incluye:** Transporte 4x4, Almuerzo, Guía
- **Punto de encuentro:** Específico por destino

### 🔗 **URLs principales:**

```
GET /api/servicios/                   → Todos los destinos
GET /api/servicios/1/                 → Destino específico
GET /api/servicios/?estado=Activo     → Solo activos
GET /api/servicios/?titulo__icontains=salar → Buscar por nombre
```

### 💡 **Ejemplo de uso:**

```javascript
// Catálogo de destinos individuales
fetch("/api/servicios/?estado=Activo")
  .then((response) => response.json())
  .then((destinos) => {
    destinos.forEach((destino) => {
      console.log(
        `${destino.titulo} - ${destino.duracion} - $${destino.precio_usd}`
      );
      console.log(`Capacidad: ${destino.capacidad_max} personas`);
    });
  });
```

---

## 🔄 **COMPARACIÓN DIRECTA**

### 📦 **API Paquetes** vs 🏕️ **API Servicios**

| Aspecto         | Paquetes                             | Servicios                            |
| --------------- | ------------------------------------ | ------------------------------------ |
| **Qué muestra** | Experiencias completas multi-destino | Destinos/actividades individuales    |
| **Precio**      | Precio total del paquete             | Precio por actividad individual      |
| **Duración**    | Multi-día (ej: "5 días, 4 noches")   | Por actividad (ej: "1 día")          |
| **Contenido**   | Múltiples destinos incluidos         | Un destino específico                |
| **Itinerario**  | Día por día organizado               | Información de la actividad          |
| **Ideal para**  | Ofertas principales, vacaciones      | Actividades específicas, comparación |

### 🎯 **Ejemplos de respuesta:**

#### 📦 **Paquete - "Full Tour Bolivia"**

```json
{
  "id": 1,
  "nombre": "Full Tour Bolivia - Experiencia Completa",
  "duracion": "5 días, 4 noches",
  "precio_base": "850.00",
  "servicios_incluidos": [
    { "titulo": "Salar de Uyuni", "precio_usd": 250.0 },
    { "titulo": "Isla del Sol", "precio_usd": 180.0 },
    { "titulo": "Tiwanaku", "precio_usd": 90.0 }
  ]
}
```

#### 🏕️ **Servicio - "Salar de Uyuni" Individual**

```json
{
  "id": 1,
  "titulo": "Salar de Uyuni",
  "duracion": "1 día",
  "precio_usd": "250.00",
  "capacidad_max": 8,
  "punto_encuentro": "Uyuni, Potosí",
  "servicios_incluidos": ["Transporte 4x4", "Almuerzo", "Guía"]
}
```

---

## 💻 **IMPLEMENTACIÓN FRONTEND - Código Listo**

### 🏠 **Homepage - Paquetes Destacados**

```html
<!-- HTML -->
<div id="paquetes-destacados" class="carousel">
  <!-- Se llena con JavaScript -->
</div>

<script>
  // JavaScript
  async function cargarPaquetesDestacados() {
    const response = await fetch("/api/paquetes/destacados/");
    const paquetes = await response.json();

    const container = document.getElementById("paquetes-destacados");
    container.innerHTML = "";

    paquetes.forEach((paquete) => {
      container.innerHTML += `
      <div class="paquete-card destacado">
        <img src="${paquete.imagen_principal}" alt="${paquete.nombre}">
        <h3>${paquete.nombre}</h3>
        <p class="duracion">${paquete.duracion}</p>
        <p class="precio">$${paquete.precios.precio_final_usd} USD</p>
        <p class="destinos">${paquete.servicios_incluidos.length} destinos incluidos</p>
        <button onclick="verPaquete(${paquete.id})">Ver Detalle</button>
      </div>
    `;
    });
  }

  // Cargar al iniciar la página
  cargarPaquetesDestacados();
</script>
```

### 🛍️ **Catálogo - Filtros de Paquetes**

```html
<!-- HTML -->
<div class="filtros">
  <input type="number" id="precio-min" placeholder="Precio mínimo" />
  <input type="number" id="precio-max" placeholder="Precio máximo" />
  <select id="duracion">
    <option value="">Todas las duraciones</option>
    <option value="día">1 día</option>
    <option value="días">Varios días</option>
  </select>
  <button onclick="buscarPaquetes()">Buscar</button>
</div>
<div id="resultados-paquetes"></div>

<script>
  async function buscarPaquetes() {
    const params = new URLSearchParams();

    const precioMin = document.getElementById("precio-min").value;
    const precioMax = document.getElementById("precio-max").value;
    const duracion = document.getElementById("duracion").value;

    if (precioMin) params.append("precio_min", precioMin);
    if (precioMax) params.append("precio_max", precioMax);
    if (duracion) params.append("duracion", duracion);

    const response = await fetch(`/api/paquetes/?${params}`);
    const paquetes = await response.json();

    const container = document.getElementById("resultados-paquetes");
    container.innerHTML = "";

    if (paquetes.length === 0) {
      container.innerHTML = "<p>No se encontraron paquetes</p>";
      return;
    }

    paquetes.forEach((paquete) => {
      container.innerHTML += `
      <div class="paquete-resultado">
        <h4>${paquete.nombre}</h4>
        <p>${paquete.descripcion.substring(0, 100)}...</p>
        <p class="precio">$${paquete.precios.precio_final_usd} USD - ${
        paquete.duracion
      }</p>
        <p class="disponibilidad">${
          paquete.disponibilidad.cupos_restantes
        } cupos disponibles</p>
      </div>
    `;
    });
  }
</script>
```

### 🏕️ **Destinos Individuales - Lista Simple**

```html
<!-- HTML -->
<div id="destinos-individuales"></div>

<script>
  async function cargarDestinos() {
    const response = await fetch("/api/servicios/?estado=Activo");
    const destinos = await response.json();

    const container = document.getElementById("destinos-individuales");
    container.innerHTML = "";

    destinos.forEach((destino) => {
      container.innerHTML += `
      <div class="destino-card">
        <img src="${destino.imagen_url}" alt="${destino.titulo}">
        <h4>${destino.titulo}</h4>
        <p class="categoria">${destino.categoria.nombre}</p>
        <p class="duracion">${destino.duracion}</p>
        <p class="precio">$${destino.precio_usd} USD</p>
        <p class="capacidad">Hasta ${destino.capacidad_max} personas</p>
        <button onclick="reservarDestino(${destino.id})">Reservar</button>
      </div>
    `;
    });
  }

  cargarDestinos();
</script>
```

---

## 🚀 **URLs de Prueba - Copiar y Usar**

### ⚡ **Pruebas Rápidas en Navegador:**

```
📦 Paquetes destacados:     http://127.0.0.1:8000/api/paquetes/destacados/
📦 Todos los paquetes:      http://127.0.0.1:8000/api/paquetes/
📦 Paquete específico:      http://127.0.0.1:8000/api/paquetes/1/
📦 Itinerario detallado:    http://127.0.0.1:8000/api/paquetes/1/itinerario/

🏕️ Todos los destinos:      http://127.0.0.1:8000/api/servicios/
🏕️ Destinos activos:        http://127.0.0.1:8000/api/servicios/?estado=Activo
🏕️ Buscar Salar:            http://127.0.0.1:8000/api/servicios/?titulo__icontains=salar
🏕️ Por precio hasta $200:   http://127.0.0.1:8000/api/servicios/?precio_usd__lte=200
```

## ✅ **CONCLUSIÓN**

- **🎯 Para mostrar ofertas turísticas completas:** Usa `/api/paquetes/`
- **🎯 Para mostrar destinos individuales:** Usa `/api/servicios/`
- **🎯 Para homepage principal:** Usa `/api/paquetes/destacados/`
- **🎯 Para búsquedas específicas:** Usa filtros en ambas APIs

**¡Ya tienes todo listo para implementar en tu frontend!** 🚀
