# 🚀 RESUMEN EJECUTIVO - API TURÍSTICA PARA FRONTEND

## ⭐ SISTEMA COMPLETO: PAQUETES + SERVICIOS/DESTINOS ✅

### 🎯 **DIFERENCIA CLAVE PARA FRONTEND**

```
📦 PAQUETES TURÍSTICOS = Experiencias Combinadas
   ├── "Full Tour Bolivia" (Salar + Isla del Sol + Tiwanaku)
   ├── "Aventura Andina" (2 destinos en fin de semana)
   └── "Descubrimiento Cultural" (1 día completo)

🏕️ SERVICIOS/DESTINOS = Actividades Individuales
   ├── "Salar de Uyuni" (destino individual)
   ├── "Isla del Sol" (destino individual)
   └── "Tiwanaku" (destino individual)
```

### 📍 **URLs PRINCIPALES PARA EL FRONTEND**

```
✅ PAQUETES COMBINADOS: /api/paquetes/
🌐 URL Completa: http://127.0.0.1:8000/api/paquetes/
🎯 Estado: OPERATIVA - Paquetes turísticos reales

✅ DESTINOS INDIVIDUALES: /api/servicios/
🌐 URL Completa: http://127.0.0.1:8000/api/servicios/
🎯 Estado: OPERATIVA - Servicios/destinos por separado
```

---

## 📦 **API DE PAQUETES TURÍSTICOS**

### **1. Listar Todos los Paquetes**

```javascript
GET /api/paquetes/
// Devuelve: Paquetes como "Full Tour Bolivia" con múltiples destinos
```

### **2. Paquetes Destacados (Para Homepage)**

```javascript
GET /api/paquetes/destacados/
// Devuelve: Hasta 6 paquetes destacados para carousel principal
```

### **3. Paquetes Disponibles (Para Reservas)**

```javascript
GET /api/paquetes/disponibles/
// Devuelve: Solo paquetes disponibles para reservar ahora
```

### **4. Itinerario Detallado**

```javascript
GET /api/paquetes/1/itinerario/
// Devuelve: Itinerario día por día del paquete
```

### **5. Filtros de Paquetes**

```javascript
GET /api/paquetes/?activo=true&destacado=true    // Paquetes destacados activos
GET /api/paquetes/?precio_min=200&precio_max=600 // Rango de precios
GET /api/paquetes/?duracion=día                  // Paquetes de 1 día
GET /api/paquetes/?disponible=true               // Solo disponibles
```

---

## �️ **API DE SERVICIOS/DESTINOS INDIVIDUALES**

### **1. Listar Todos los Destinos**

```javascript
GET /api/servicios/
// Devuelve: Destinos individuales como "Salar de Uyuni", "Isla del Sol"
```

### **2. Ver Destino Específico**

```javascript
GET /api/servicios/1/
// Devuelve: Información completa de un destino individual
```

### **3. Filtros de Destinos**

```javascript
GET /api/servicios/?estado=Activo                    // Solo destinos activos
GET /api/servicios/?categoria=1                      // Por categoría (Tours)
GET /api/servicios/?precio_usd__gte=100              // Precio mínimo $100
GET /api/servicios/?titulo__icontains=salar          // Buscar "Salar"
GET /api/servicios/?capacidad_max__gte=15            // Capacidad mínima
```

---

## 📋 **ESTRUCTURA DE RESPUESTA**

Cada paquete incluye **TODO EN UNA SOLA LLAMADA**:

```json
{
  "count": 10,
  "next": null,
  "previous": null,
  "results": [
    {
      "id": 1,
      "descripcion": "Tour al majestionoso desierto de sal más grande del mundo",
      "fecha_inicio": "2025-07-01",
      "fecha_fin": "2025-07-31",
      "tipo_descuento": "%",
      "monto": "20.00",
      "created_at": "2025-01-15T10:00:00Z",
      "updated_at": "2025-01-15T10:00:00Z",

      "servicios_incluidos": [
        {
          "id": 1,
          "titulo": "Transporte 4x4 especializado",
          "descripcion": "Vehículo todo terreno para el Salar de Uyuni",
          "duracion": "8h",
          "capacidad_max": 20,
          "punto_encuentro": "Plaza Principal de Uyuni",
          "precio_usd": "20.00",
          "categoria": "Transporte",
          "imagen_url": "https://example.com/transport.jpg",
          "estado": "Activo",
          "servicios_incluidos": ["Conductor", "Combustible", "Seguro"]
        },
        {
          "id": 2,
          "titulo": "Guía turístico especializado",
          "descripcion": "Guía bilingüe experto en el Salar",
          "duracion": "8h",
          "capacidad_max": 20,
          "punto_encuentro": "Plaza Principal de Uyuni",
          "precio_usd": "15.00",
          "categoria": "Guía",
          "imagen_url": "https://example.com/guide.jpg",
          "estado": "Activo",
          "servicios_incluidos": ["Conocimiento local", "Traducción"]
        }
      ],

      "cupones_disponibles": [
        {
          "id": 1,
          "usos_restantes": 48,
          "cantidad_max": 50,
          "nro_usos": 2
        }
      ],

      "precio_total_servicios": {
        "total_usd": 35.0,
        "cantidad_servicios": 2
      }
    }
  ]
}
```

---

## 💻 **CÓDIGO DE EJEMPLO PARA FRONTEND**

### **React/JavaScript - Obtener Paquetes**

```javascript
import React, { useState, useEffect } from "react";

const PaquetesComponent = () => {
  const [paquetes, setPaquetes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPaquetes();
  }, []);

  const fetchPaquetes = async () => {
    try {
      // ✅ UNA SOLA LLAMADA obtiene TODO
      const response = await fetch(
        "http://127.0.0.1:8000/api/paquetes/?activo=true"
      );
      const data = await response.json();
      setPaquetes(data.results);
      setLoading(false);
    } catch (error) {
      console.error("Error al obtener paquetes:", error);
      setLoading(false);
    }
  };

  if (loading) return <div>Cargando paquetes...</div>;

  return (
    <div className="paquetes-list">
      {paquetes.map((paquete) => (
        <div key={paquete.id} className="paquete-card">
          <h3>{paquete.descripcion}</h3>

          <div className="descuento">
            Descuento: {paquete.tipo_descuento}
            {paquete.monto}
          </div>

          <div className="servicios">
            <h4>Servicios Incluidos ({paquete.servicios_incluidos.length}):</h4>
            {paquete.servicios_incluidos.map((servicio) => (
              <div key={servicio.id} className="servicio">
                <strong>{servicio.titulo}</strong>
                <p>{servicio.descripcion}</p>
                <span>${servicio.precio_usd} USD</span>
              </div>
            ))}
          </div>

          <div className="precio-total">
            <strong>
              Precio Total: ${paquete.precio_total_servicios.total_usd} USD
            </strong>
          </div>

          {paquete.cupones_disponibles.length > 0 && (
            <div className="cupones">
              Cupones disponibles:{" "}
              {paquete.cupones_disponibles[0].usos_restantes}
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default PaquetesComponent;
```

### **Vue.js - Obtener Paquetes**

```javascript
<template>
  <div class="paquetes-container">
    <h2>Paquetes Turísticos Disponibles</h2>

    <div v-if="loading" class="loading">Cargando paquetes...</div>

    <div v-else class="paquetes-grid">
      <div
        v-for="paquete in paquetes"
        :key="paquete.id"
        class="paquete-card"
        @click="verDetallePaquete(paquete.id)"
      >
        <h3>{{ paquete.descripcion }}</h3>

        <div class="descuento-badge">
          {{ paquete.tipo_descuento }}{{ paquete.monto }} OFF
        </div>

        <div class="servicios-incluidos">
          <h4>Incluye {{ paquete.servicios_incluidos.length }} servicios:</h4>
          <ul>
            <li v-for="servicio in paquete.servicios_incluidos" :key="servicio.id">
              {{ servicio.titulo }} - ${{ servicio.precio_usd }} USD
            </li>
          </ul>
        </div>

        <div class="precio-final">
          <strong>${{ paquete.precio_total_servicios.total_usd }} USD</strong>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'PaquetesVue',
  data() {
    return {
      paquetes: [],
      loading: true
    }
  },

  async mounted() {
    await this.cargarPaquetes();
  },

  methods: {
    async cargarPaquetes() {
      try {
        // ✅ UNA SOLA LLAMADA obtiene TODO
        const response = await fetch('http://127.0.0.1:8000/api/paquetes/?activo=true');
        const data = await response.json();
        this.paquetes = data.results;
        this.loading = false;
      } catch (error) {
        console.error('Error:', error);
        this.loading = false;
      }
    },

    async verDetallePaquete(paqueteId) {
      // ✅ Paquete específico completo
      const response = await fetch(`http://127.0.0.1:8000/api/paquetes/${paqueteId}/`);
      const paquete = await response.json();

      // Aquí tienes TODA la información del paquete
      console.log('Paquete completo:', paquete);
      // Mostrar modal, navegar a detalle, etc.
    }
  }
}
</script>
```

### **Angular - Service y Component**

```typescript
// paquetes.service.ts
import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";

export interface Paquete {
  id: number;
  descripcion: string;
  fecha_inicio: string;
  fecha_fin: string;
  tipo_descuento: string;
  monto: string;
  servicios_incluidos: any[];
  cupones_disponibles: any[];
  precio_total_servicios: {
    total_usd: number;
    cantidad_servicios: number;
  };
}

@Injectable({
  providedIn: "root",
})
export class PaquetesService {
  private baseUrl = "http://127.0.0.1:8000/api";

  constructor(private http: HttpClient) {}

  // ✅ Obtener todos los paquetes vigentes
  getPaquetesVigentes(): Observable<any> {
    return this.http.get(`${this.baseUrl}/paquetes/?activo=true`);
  }

  // ✅ Obtener paquete específico completo
  getPaqueteCompleto(id: number): Observable<Paquete> {
    return this.http.get<Paquete>(`${this.baseUrl}/paquetes/${id}/`);
  }

  // ✅ Obtener mejores ofertas
  getMejoresOfertas(): Observable<any> {
    return this.http.get(
      `${this.baseUrl}/paquetes/?tipo_descuento=%&descuento_min=15`
    );
  }
}

// paquetes.component.ts
import { Component, OnInit } from "@angular/core";
import { PaquetesService, Paquete } from "./paquetes.service";

@Component({
  selector: "app-paquetes",
  template: `
    <div class="paquetes-container">
      <h2>Paquetes Turísticos</h2>

      <div *ngIf="loading" class="loading">Cargando...</div>

      <div *ngIf="!loading" class="paquetes-list">
        <div *ngFor="let paquete of paquetes" class="paquete-item">
          <h3>{{ paquete.descripcion }}</h3>

          <div class="descuento">
            Descuento: {{ paquete.tipo_descuento }}{{ paquete.monto }}
          </div>

          <div class="servicios">
            <strong
              >{{ paquete.servicios_incluidos.length }} servicios
              incluidos</strong
            >
            <ul>
              <li *ngFor="let servicio of paquete.servicios_incluidos">
                {{ servicio.titulo }} - \${{ servicio.precio_usd }} USD
              </li>
            </ul>
          </div>

          <div class="precio-total">
            <strong
              >\${{ paquete.precio_total_servicios.total_usd }} USD</strong
            >
          </div>

          <button (click)="verDetalle(paquete.id)">Ver Detalle</button>
        </div>
      </div>
    </div>
  `,
})
export class PaquetesComponent implements OnInit {
  paquetes: Paquete[] = [];
  loading = true;

  constructor(private paquetesService: PaquetesService) {}

  ngOnInit(): void {
    this.cargarPaquetes();
  }

  cargarPaquetes(): void {
    this.paquetesService.getPaquetesVigentes().subscribe(
      (data) => {
        this.paquetes = data.results;
        this.loading = false;
      },
      (error) => {
        console.error("Error al cargar paquetes:", error);
        this.loading = false;
      }
    );
  }

  verDetalle(paqueteId: number): void {
    this.paquetesService.getPaqueteCompleto(paqueteId).subscribe((paquete) => {
      console.log("Paquete completo:", paquete);
      // Mostrar detalle, navegar, etc.
    });
  }
}
```

---

## 🔧 **FILTROS AVANZADOS DISPONIBLES**

### **Filtros por Fecha**

```javascript
// Paquetes que inician después de hoy
GET /api/paquetes/?fecha_inicio__gte=2025-01-15

// Paquetes que terminan antes de una fecha
GET /api/paquetes/?fecha_fin__lte=2025-12-31

// Paquetes vigentes en rango específico
GET /api/paquetes/?fecha_inicio__lte=2025-06-01&fecha_fin__gte=2025-06-01
```

### **Filtros por Descuento**

```javascript
// Solo descuentos porcentuales
GET /api/paquetes/?tipo_descuento=%

// Solo descuentos fijos en dinero
GET /api/paquetes/?tipo_descuento=$

// Descuento mínimo del 20%
GET /api/paquetes/?descuento_min=20
```

### **Combinación de Filtros**

```javascript
// Paquetes vigentes con descuentos porcentuales del 15% o más
GET /api/paquetes/?activo=true&tipo_descuento=%&descuento_min=15
```

---

## 🚨 **IMPORTANTE PARA DESARROLLADORES**

### ✅ **LO QUE SÍ DEBES HACER:**

- **USA `/api/paquetes/`** para mostrar paquetes al usuario
- Una sola llamada obtiene toda la información necesaria
- Maneja la paginación (`next`, `previous`, `count`)
- Usa filtros para mejorar la UX (activo=true, etc.)

### ❌ **LO QUE NO DEBES HACER:**

- **NO uses `/api/campanias/`** para el frontend (solo administración)
- **NO hagas múltiples llamadas** para armar un paquete manualmente
- **NO ignores** los servicios_incluidos y cupones_disponibles

### 🔒 **Autenticación**

- **Lectura:** No requiere autenticación
- **Escritura:** Usa `/api/campanias/` y `/api/campania-servicios/` (requiere admin)

---

## 📞 **SOPORTE TÉCNICO**

### **URLs de Prueba:**

```
🧪 Desarrollo: http://127.0.0.1:8000/api/paquetes/
🔍 Documentación: http://127.0.0.1:8000/api/ (Django REST Framework)
```

### **Códigos de Estado:**

```
200 - OK (datos obtenidos correctamente)
404 - Not Found (paquete no existe)
500 - Server Error (error interno)
```

### **Ejemplo de Error:**

```json
{
  "detail": "No encontrado."
}
```

---

## 🛠️ **TROUBLESHOOTING Y SOLUCIÓN DE PROBLEMAS**

### **❌ Error: "Router with basename 'campania' is already registered"**

```bash
# Problema: PaqueteViewSet usa el mismo modelo que CampaniaViewSet
# Solución aplicada en condominio/urls.py:

router.register(r'paquetes', PaqueteViewSet, basename='paquete')
# ✅ Especifica basename único para evitar conflicto
```

### **🔧 Verificar que la API está funcionando:**

```bash
# 1. Activar entorno virtual
.\venv\Scripts\Activate.ps1

# 2. Verificar Django sin errores
python manage.py check

# 3. Verificar ViewSets registrados
python -c "import os; os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings'); import django; django.setup(); from condominio.urls import router; print([r[1].__name__ for r in router.registry])"

# 4. Debe mostrar PaqueteViewSet en la lista
```

### **🚀 Iniciar el servidor:**

```bash
# En el directorio del proyecto con venv activo:
python manage.py runserver

# La API estará disponible en:
# http://127.0.0.1:8000/api/paquetes/
```

### **🧪 Probar la API:**

```bash
# Método 1: Navegador web
http://127.0.0.1:8000/api/paquetes/

# Método 2: curl
curl -X GET "http://127.0.0.1:8000/api/paquetes/"

# Método 3: Postman
Importar: Sistema_Paquetes_Turisticos.postman_collection.json
Usar: ⭐ 00. PAQUETES COMPLETOS - NUEVA API
```

---

**✅ API VERIFICADA Y FUNCIONANDO**  
**🚀 Una sola llamada = Paquete completo**  
**📱 Compatible con React, Vue, Angular y cualquier frontend**  
**🔧 Problema de basename resuelto correctamente**

_Versión: 2.1 | Fecha: Enero 2025 | Sistema de Paquetes Turísticos_  
_🛠️ Incluye fix para conflicto de router basename_
