# 📋 REFERENCIA RÁPIDA - URLs del Sistema Turístico

## 🚀 **URLs PRINCIPALES PARA FRONTEND**

### 📦 **PAQUETES TURÍSTICOS** (Experiencias Combinadas)

```
🌐 Base: http://127.0.0.1:8000/api/paquetes/

GET /api/paquetes/                    → Lista todos los paquetes
GET /api/paquetes/destacados/         → Solo paquetes destacados (máx 6)
GET /api/paquetes/disponibles/        → Solo paquetes disponibles para reservar
GET /api/paquetes/{id}/               → Detalle completo del paquete
GET /api/paquetes/{id}/itinerario/    → Itinerario día por día
```

### 🏕️ **SERVICIOS/DESTINOS** (Actividades Individuales)

```
🌐 Base: http://127.0.0.1:8000/api/servicios/

GET /api/servicios/                   → Lista todos los destinos
GET /api/servicios/{id}/              → Detalle del destino específico
POST /api/servicios/                  → Crear nuevo destino (admin)
PUT /api/servicios/{id}/              → Actualizar destino (admin)
DELETE /api/servicios/{id}/           → Eliminar destino (admin)
```

### 🏷️ **CATEGORÍAS**

```
🌐 Base: http://127.0.0.1:8000/api/categorias/

GET /api/categorias/                  → Lista todas las categorías
GET /api/categorias/{id}/             → Detalle de categoría específica
```

---

## 🔍 **FILTROS DISPONIBLES**

### 📦 **Filtros para Paquetes**

```
# Por estado y disponibilidad
/api/paquetes/?activo=true                    → Solo paquetes activos
/api/paquetes/?disponible=true               → Solo paquetes reservables
/api/paquetes/?destacado=true                → Solo paquetes destacados

# Por precio (USD)
/api/paquetes/?precio_min=200                → Precio mínimo $200
/api/paquetes/?precio_max=600                → Precio máximo $600
/api/paquetes/?precio_min=200&precio_max=600 → Rango $200-$600

# Por duración
/api/paquetes/?duracion=día                  → Paquetes de 1 día
/api/paquetes/?duracion=días                 → Paquetes multi-día

# Combinados
/api/paquetes/?destacado=true&disponible=true → Destacados disponibles
```

### 🏕️ **Filtros para Servicios/Destinos**

```
# Por estado
/api/servicios/?estado=Activo                → Solo destinos activos

# Por categoría
/api/servicios/?categoria=1                  → Destinos de categoría ID 1

# Por precio USD
/api/servicios/?precio_usd__gte=100          → Precio mínimo $100
/api/servicios/?precio_usd__lte=300          → Precio máximo $300
/api/servicios/?precio_usd__gte=100&precio_usd__lte=300 → Rango $100-$300

# Por precio BOB
/api/servicios/?precio_bob__gte=600          → Precio mínimo 600 BOB
/api/servicios/?precio_bob__lte=2000         → Precio máximo 2000 BOB

# Búsqueda por título
/api/servicios/?titulo__icontains=salar      → Buscar "Salar" en título
/api/servicios/?titulo__icontains=isla       → Buscar "Isla" en título

# Por capacidad
/api/servicios/?capacidad_max__gte=15        → Capacidad mínima 15 personas
```

---

## 📖 **EJEMPLOS DE USO PRÁCTICOS**

### 🎯 **Homepage - Paquetes Destacados**

```javascript
// Para carousel principal de homepage
fetch("http://127.0.0.1:8000/api/paquetes/destacados/")
  .then((response) => response.json())
  .then((paquetes) => {
    // Renderizar hasta 6 paquetes destacados
    console.log("Paquetes destacados:", paquetes);
  });
```

### 🎯 **Catálogo Principal - Todos los Paquetes**

```javascript
// Para página de catálogo/búsqueda
fetch("http://127.0.0.1:8000/api/paquetes/")
  .then((response) => response.json())
  .then((paquetes) => {
    console.log("Todos los paquetes:", paquetes);
  });
```

### 🎯 **Búsqueda con Filtros - Paquetes por Precio**

```javascript
// Paquetes entre $200-$600 disponibles
fetch(
  "http://127.0.0.1:8000/api/paquetes/?precio_min=200&precio_max=600&disponible=true"
)
  .then((response) => response.json())
  .then((paquetes) => {
    console.log("Paquetes filtrados:", paquetes);
  });
```

### 🎯 **Página de Producto - Detalle + Itinerario**

```javascript
// Información completa del paquete ID 1
Promise.all([
  fetch("http://127.0.0.1:8000/api/paquetes/1/"),
  fetch("http://127.0.0.1:8000/api/paquetes/1/itinerario/"),
])
  .then((responses) => Promise.all(responses.map((r) => r.json())))
  .then(([paquete, itinerario]) => {
    console.log("Paquete completo:", paquete);
    console.log("Itinerario detallado:", itinerario);
  });
```

### 🎯 **Destinos Individuales - Catálogo Alternativo**

```javascript
// Para mostrar destinos como actividades por separado
fetch("http://127.0.0.1:8000/api/servicios/?estado=Activo")
  .then((response) => response.json())
  .then((destinos) => {
    console.log("Destinos individuales:", destinos);
  });
```

### 🎯 **Búsqueda Específica - Destino por Nombre**

```javascript
// Buscar específicamente "Salar de Uyuni"
fetch("http://127.0.0.1:8000/api/servicios/?titulo__icontains=salar")
  .then((response) => response.json())
  .then((destinos) => {
    console.log('Destinos con "Salar":', destinos);
  });
```

---

## 🔧 **CASOS DE USO POR TIPO DE PÁGINA**

### 🏠 **Homepage**

```
✅ Paquetes destacados: /api/paquetes/destacados/
✅ Destinos populares: /api/servicios/?estado=Activo (primeros 6)
```

### 📱 **Aplicación Móvil - Pantalla Principal**

```
✅ Ofertas principales: /api/paquetes/?destacado=true&disponible=true
✅ Tours rápidos: /api/paquetes/?duracion=día
```

### 🛍️ **Catálogo/Tienda**

```
✅ Lista completa: /api/paquetes/
✅ Filtros de precio: /api/paquetes/?precio_min={min}&precio_max={max}
✅ Solo disponibles: /api/paquetes/?disponible=true
```

### 🔍 **Buscador Avanzado**

```
✅ Paquetes multi-filtro: /api/paquetes/?destacado={bool}&precio_min={min}&duracion={text}
✅ Destinos por rango: /api/servicios/?precio_usd__gte={min}&precio_usd__lte={max}
```

### 📄 **Página de Producto Individual**

```
✅ Información básica: /api/paquetes/{id}/
✅ Itinerario completo: /api/paquetes/{id}/itinerario/
✅ Destinos relacionados: /api/servicios/ (para mostrar alternativas)
```

### 🎯 **Página de Comparación**

```
✅ Paquete completo: /api/paquetes/{id}/
✅ Destinos por separado: /api/servicios/?id__in={ids}
```

---

## ⚡ **URLs DE PRUEBA DIRECTA (Copiar y Pegar)**

### 📦 **Paquetes - URLs Listas**

```
http://127.0.0.1:8000/api/paquetes/
http://127.0.0.1:8000/api/paquetes/destacados/
http://127.0.0.1:8000/api/paquetes/disponibles/
http://127.0.0.1:8000/api/paquetes/1/
http://127.0.0.1:8000/api/paquetes/1/itinerario/
http://127.0.0.1:8000/api/paquetes/?precio_min=200&precio_max=600
http://127.0.0.1:8000/api/paquetes/?destacado=true&disponible=true
```

### 🏕️ **Destinos - URLs Listas**

```
http://127.0.0.1:8000/api/servicios/
http://127.0.0.1:8000/api/servicios/?estado=Activo
http://127.0.0.1:8000/api/servicios/1/
http://127.0.0.1:8000/api/servicios/?precio_usd__lte=200
http://127.0.0.1:8000/api/servicios/?titulo__icontains=salar
http://127.0.0.1:8000/api/servicios/?categoria=1
```

### 🏷️ **Utilidades - URLs Listas**

```
http://127.0.0.1:8000/api/categorias/
http://127.0.0.1:8000/api/
```

---

## 🎯 **DECISIÓN RÁPIDA: ¿Qué API Usar?**

```
❓ ¿Quieres mostrar experiencias completas de múltiples días?
   → Usa /api/paquetes/

❓ ¿Quieres mostrar actividades individuales que se pueden reservar por separado?
   → Usa /api/servicios/

❓ ¿Quieres un carousel de ofertas principales?
   → Usa /api/paquetes/destacados/

❓ ¿Quieres que usuarios busquen por precio?
   → Usa filtros: ?precio_min=X&precio_max=Y

❓ ¿Quieres mostrar solo lo que está disponible HOY?
   → Usa /api/paquetes/disponibles/ o /api/servicios/?estado=Activo
```
