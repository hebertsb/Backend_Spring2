# 🎯 GUÍA DEFINITIVA DE APIs - SISTEMA TURÍSTICO COMPLETO

## Solución Completa: Paquetes Turísticos + Destinos Individuales

### ✅ **PROBLEMA RESUELTO - NUEVA IMPLEMENTACIÓN**

```
❌ Antes: El frontend mostraba destinos individuales como si fueran paquetes
✅ Ahora: Sistema separado y claro

📦 PAQUETES TURÍSTICOS (Experiencias Completas):
   ├── "Full Tour Bolivia" - Salar + Isla del Sol + Tiwanaku (5 días, $850)
   ├── "Aventura Andina" - 2 destinos principales (2 días, $350)
   └── "Descubrimiento Cultural" - Tour completo (1 día, $120)

🏕️ DESTINOS INDIVIDUALES (Actividades por Separado):
   ├── "Salar de Uyuni" ($250)
   ├── "Isla del Sol" ($180)
   ├── "Tiwanaku" ($90)
   ├── "Cristo de la Concordia" ($60)
   └── ...más destinos
```

### 🔍 **DATOS REALES EN BASE DE DATOS**

```sql
-- PAQUETES TURÍSTICOS (tabla: condominio_paquete)
1: Full Tour Bolivia - Experiencia Completa (5 días, $850)
2: Aventura Andina - Escapada de Fin de Semana (2 días, $350)
3: Descubrimiento Cultural - Tour de 1 Día (1 día, $120)

-- DESTINOS INDIVIDUALES (tabla: condominio_servicio)
1: Salar de Uyuni ($250)
2: Isla del Sol ($180)
3: Tiwanaku ($90)
4: Cristo de la Concordia ($60)
5: Laguna Colorada ($210)
6: Camino de la Muerte ($150)
7: Coroico ($120)
8: Samaipata ($170)
9: Parque Nacional Madidi ($300)
10: Ciudad Blanca de Sucre ($100)
```

---

## 📊 **ENDPOINTS DISPONIBLES ACTUALIZADOS**

### **1. `/api/paquetes/` - PAQUETES TURÍSTICOS COMPLETOS** ⭐ **NUEVO**

**🎯 Úsalo para:** Mostrar experiencias turísticas completas que combinan múltiples destinos

**📋 Respuesta:**

```json
[
  {
    "id": 1,
    "nombre": "Full Tour Bolivia - Experiencia Completa",
    "descripcion": "El paquete más completo para conocer los principales atractivos...",
    "duracion": "5 días, 4 noches",
    "precio_base": "850.00",
    "precio_bob": "5865.00",
    "destacado": true,
    "servicios_incluidos": [
      {
        "id": 1,
        "titulo": "Salar de Uyuni",
        "precio_usd": 250.0,
        "categoria": "Tours"
      },
      {
        "id": 2,
        "titulo": "Isla del Sol",
        "precio_usd": 180.0,
        "categoria": "Tours"
      }
    ],
    "disponibilidad": {
      "cupos_restantes": 20,
      "esta_disponible": true
    }
  }
]
```

### **2. `/api/servicios/` - DESTINOS INDIVIDUALES** ⭐ **ACTUALIZADO**

**🎯 Úsalo para:** Mostrar destinos/actividades que se pueden reservar individualmente

**📋 Respuesta:**

```json
[
  {
    "id": 1,
    "titulo": "Salar de Uyuni",
    "descripcion": "Experiencia única en el salar más grande del mundo...",
    "duracion": "1 día",
    "capacidad_max": 8,
      "punto_encuentro": "Plaza Principal de Uyuni",
      "precio_usd": "250.00",
      "estado": "Activo",
      "imagen_url": "https://images.pexels.com/photos/17507607/pexels-photo-17507607.jpeg",
      "categoria": {
        "id": 1,
        "nombre": "Aventura"
      },
      "servicios_incluidos": ["Guía", "Transporte", "Hotel"]
    }
  ]
}
```

**✅ Ventajas:**

- Títulos reales de destinos turísticos
- Precios individuales por servicio
- Imágenes reales de destinos
- Información completa (duración, capacidad, punto encuentro)
- Categorización por tipo de aventura

### **2. `/api/campanias/` - PROMOCIONES Y OFERTAS**

**🎯 Úsalo para:** Mostrar descuentos y promociones (administración)

**📋 Respuesta:**

```json
{
  "count": 10,
  "results": [
    {
      "id": 1,
      "descripcion": "Promo Primavera",
      "fecha_inicio": "2025-09-01",
      "fecha_fin": "2025-10-31",
      "tipo_descuento": "%",
      "monto": "10.00"
    }
  ]
}
```

**⚠️ Problema:** Solo muestra nombres de promociones, no destinos reales

### **3. `/api/paquetes/` - PROMOCIONES CON SERVICIOS INCLUIDOS**

**🎯 Úsalo para:** Mostrar ofertas con destinos incluidos y descuentos

**📋 Respuesta:**

```json
{
  "count": 10,
  "results": [
    {
      "id": 1,
      "descripcion": "Promo Primavera",
      "tipo_descuento": "%",
      "monto": "10.00",
      "fecha_inicio": "2025-09-01",
      "fecha_fin": "2025-10-31",
      "servicios_incluidos": [
        {
          "id": 1,
          "titulo": "Salar de Uyuni",
          "descripcion": "Tour al majestuoso desierto de sal...",
          "precio_usd": "250.00",
          "categoria": "Aventura",
          "imagen_url": "https://images.pexels.com/photos/17507607/pexels-photo-17507607.jpeg"
        }
      ],
      "precio_total_servicios": {
        "total_usd": 250.0,
        "cantidad_servicios": 1
      },
      "cupones_disponibles": [
        {
          "id": 1,
          "usos_restantes": 48,
          "cantidad_max": 50
        }
      ]
    }
  ]
}
```

**⚠️ Problema:** El título principal sigue siendo la promoción, no el destino

---

## 🚀 **SOLUCIONES PARA EL FRONTEND**

### **SOLUCIÓN 1: Cambiar a `/api/servicios/` (Recomendada)**

**✅ Para mostrar catálogo de destinos turísticos:**

```javascript
// Mostrar destinos reales
async function cargarDestinos() {
  const response = await fetch("http://127.0.0.1:8000/api/servicios/");
  const data = await response.json();

  data.results.forEach((destino) => {
    console.log("Destino:", destino.titulo); // "Salar de Uyuni"
    console.log("Descripción:", destino.descripcion); // "Tour al majestuoso..."
    console.log("Precio:", destino.precio_usd); // "250.00"
    console.log("Imagen:", destino.imagen_url); // URL real
    console.log("Duración:", destino.duracion); // "8h"
    console.log("Categoría:", destino.categoria.nombre); // "Aventura"
  });
}
```

### **SOLUCIÓN 2: Usar servicios de dentro de `/api/paquetes/`**

**✅ Para mostrar ofertas con descuentos:**

```javascript
// Mostrar destinos con descuentos incluidos
async function cargarOfertas() {
  const response = await fetch("http://127.0.0.1:8000/api/paquetes/");
  const data = await response.json();

  data.results.forEach((paquete) => {
    // Información de la oferta
    const descuento = paquete.tipo_descuento + paquete.monto;
    console.log("Oferta:", descuento + " de descuento");

    // MOSTRAR LOS DESTINOS INCLUIDOS (no el nombre de la promoción)
    paquete.servicios_incluidos.forEach((destino) => {
      console.log("Destino:", destino.titulo); // "Salar de Uyuni"
      console.log("Precio original:", destino.precio_usd);
      console.log(
        "Con descuento:",
        aplicarDescuento(destino.precio_usd, paquete)
      );
    });
  });
}

function aplicarDescuento(precio, paquete) {
  if (paquete.tipo_descuento === "%") {
    return precio * (1 - paquete.monto / 100);
  } else {
    return precio - paquete.monto;
  }
}
```

### **SOLUCIÓN 3: Filtrar servicios activos**

**✅ Solo mostrar destinos disponibles:**

```javascript
// Filtrar solo servicios activos
fetch("http://127.0.0.1:8000/api/servicios/?estado=Activo")
  .then((response) => response.json())
  .then((data) => {
    // Solo destinos activos disponibles para reservar
  });
```

---

## 📱 **EJEMPLOS DE IMPLEMENTACIÓN**

### **React Component - Catálogo de Destinos**

```jsx
import React, { useState, useEffect } from "react";

const CatalogoDestinos = () => {
  const [destinos, setDestinos] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    cargarDestinos();
  }, []);

  const cargarDestinos = async () => {
    try {
      // ✅ USAR /api/servicios/ para destinos reales
      const response = await fetch(
        "http://127.0.0.1:8000/api/servicios/?estado=Activo"
      );
      const data = await response.json();
      setDestinos(data.results);
      setLoading(false);
    } catch (error) {
      console.error("Error al cargar destinos:", error);
      setLoading(false);
    }
  };

  if (loading) return <div>Cargando destinos...</div>;

  return (
    <div className="catalogo-destinos">
      <h2>Destinos Turísticos Disponibles</h2>
      <div className="destinos-grid">
        {destinos.map((destino) => (
          <div key={destino.id} className="destino-card">
            <img
              src={destino.imagen_url}
              alt={destino.titulo}
              className="destino-imagen"
            />
            <div className="destino-info">
              <h3>{destino.titulo}</h3>
              <p>{destino.descripcion}</p>

              <div className="destino-detalles">
                <span className="duracion">⏰ {destino.duracion}</span>
                <span className="capacidad">
                  👥 Máx. {destino.capacidad_max} personas
                </span>
                <span className="categoria">
                  🏷️ {destino.categoria?.nombre}
                </span>
              </div>

              <div className="destino-precio">
                <strong>${destino.precio_usd} USD</strong>
              </div>

              <div className="servicios-incluidos">
                <h4>Incluye:</h4>
                <ul>
                  {destino.servicios_incluidos.map((servicio, index) => (
                    <li key={index}>{servicio}</li>
                  ))}
                </ul>
              </div>

              <button
                className="btn-reservar"
                onClick={() => reservarDestino(destino)}
              >
                Reservar Ahora
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const reservarDestino = (destino) => {
  console.log("Reservando:", destino.titulo);
  // Lógica de reserva aquí
};

export default CatalogoDestinos;
```

### **Vue.js Component - Ofertas con Descuentos**

```vue
<template>
  <div class="ofertas-container">
    <h2>Ofertas Especiales</h2>

    <div v-if="loading" class="loading">Cargando ofertas...</div>

    <div v-else class="ofertas-list">
      <div v-for="paquete in paquetes" :key="paquete.id" class="oferta-card">
        <div class="descuento-badge">
          {{ paquete.tipo_descuento }}{{ paquete.monto }} OFF
        </div>

        <!-- MOSTRAR LOS DESTINOS INCLUIDOS -->
        <div
          v-for="destino in paquete.servicios_incluidos"
          :key="destino.id"
          class="destino-en-oferta"
        >
          <img :src="destino.imagen_url" :alt="destino.titulo" />
          <h3>{{ destino.titulo }}</h3>
          <p>{{ destino.descripcion }}</p>

          <div class="precios">
            <span class="precio-original">${{ destino.precio_usd }} USD</span>
            <span class="precio-oferta">
              ${{ calcularPrecioConDescuento(destino.precio_usd, paquete) }} USD
            </span>
          </div>
        </div>

        <div class="validez-oferta">Válida hasta: {{ paquete.fecha_fin }}</div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "OfertasEspeciales",
  data() {
    return {
      paquetes: [],
      loading: true,
    };
  },

  async mounted() {
    await this.cargarOfertas();
  },

  methods: {
    async cargarOfertas() {
      try {
        // ✅ USAR /api/paquetes/ para ofertas con destinos incluidos
        const response = await fetch("http://127.0.0.1:8000/api/paquetes/");
        const data = await response.json();
        this.paquetes = data.results;
        this.loading = false;
      } catch (error) {
        console.error("Error:", error);
        this.loading = false;
      }
    },

    calcularPrecioConDescuento(precio, paquete) {
      const precioNum = parseFloat(precio);
      if (paquete.tipo_descuento === "%") {
        return (precioNum * (1 - paquete.monto / 100)).toFixed(2);
      } else {
        return (precioNum - paquete.monto).toFixed(2);
      }
    },
  },
};
</script>
```

---

## 🎯 **RESUMEN DE RECOMENDACIONES**

### **✅ Para mostrar CATÁLOGO DE DESTINOS:**

```javascript
GET /api/servicios/?estado=Activo
// Devuelve: "Salar de Uyuni", "Isla del Sol", etc.
```

### **✅ Para mostrar OFERTAS CON DESCUENTOS:**

```javascript
GET /api/paquetes/
// Usar: paquete.servicios_incluidos[].titulo (no paquete.descripcion)
```

### **❌ NO usar para destinos:**

```javascript
GET /api/campanias/
// Devuelve: "Promo Primavera", "Viaje en Pareja" (son promociones)
```

---

## 🔧 **VERIFICACIÓN RÁPIDA**

**Comprobar qué devuelve cada endpoint:**

```bash
# 1. Iniciar servidor Django
python manage.py runserver

# 2. Verificar endpoints en navegador:
http://127.0.0.1:8000/api/servicios/     # ← DESTINOS REALES
http://127.0.0.1:8000/api/campanias/    # ← PROMOCIONES
http://127.0.0.1:8000/api/paquetes/     # ← PROMOCIONES + SERVICIOS
```

**✅ El frontend debe cambiar a `/api/servicios/` para mostrar destinos turísticos reales como "Salar de Uyuni", "Isla del Sol", etc.**

---

_🎯 Guía definitiva para mostrar destinos turísticos reales_  
_📅 Versión: 3.0 | Enero 2025_  
_🔧 Solución al problema: promociones vs destinos_
