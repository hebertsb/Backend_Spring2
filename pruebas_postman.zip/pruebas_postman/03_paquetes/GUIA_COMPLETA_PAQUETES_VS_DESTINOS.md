# 🎯 GUÍA COMPLETA: PAQUETES vs DESTINOS - APIs para Frontend

## 📖 **CONCEPTOS FUNDAMENTALES**

### 🔀 **¿Cuándo usar cada API?**

| Caso de Uso Frontend                   | API a Usar | Endpoint                                  |
| -------------------------------------- | ---------- | ----------------------------------------- |
| **Catálogo principal de ofertas**      | Paquetes   | `/api/paquetes/`                          |
| **Homepage - Carousel destacados**     | Paquetes   | `/api/paquetes/destacados/`               |
| **Búsqueda de experiencias completas** | Paquetes   | `/api/paquetes/?disponible=true`          |
| **Mostrar destinos individuales**      | Servicios  | `/api/servicios/`                         |
| **Búsqueda por destino específico**    | Servicios  | `/api/servicios/?titulo__icontains=salar` |
| **Filtros por precio individual**      | Servicios  | `/api/servicios/?precio_usd__lte=200`     |

---

## 📦 **PAQUETES TURÍSTICOS - Experiencias Combinadas**

### 🎯 **¿Qué son los Paquetes?**

Combinaciones de múltiples destinos/servicios en una sola experiencia turística completa.

**Ejemplos reales:**

- **"Full Tour Bolivia"** = Salar de Uyuni + Isla del Sol + Tiwanaku (5 días)
- **"Aventura Andina"** = 2 destinos principales (2 días)
- **"Descubrimiento Cultural"** = Tour cultural completo (1 día)

### 🔗 **Endpoints de Paquetes**

#### **Listar Paquetes - Catálogo Principal**

```http
GET /api/paquetes/
```

**Respuesta (ejemplo):**

```json
[
  {
    "id": 1,
    "nombre": "Full Tour Bolivia - Experiencia Completa",
    "descripcion": "El paquete más completo para conocer los principales atractivos turísticos de Bolivia...",
    "duracion": "5 días, 4 noches",
    "precio_base": "850.00",
    "precio_bob": "5865.00",
    "destacado": true,
    "estado": "Activo",
    "servicios_incluidos": [
      {
        "id": 1,
        "titulo": "Salar de Uyuni",
        "precio_usd": 250.0,
        "categoria": "Tours"
      },
      {
        "id": 2,
        "titulo": "Isla del Sol",
        "precio_usd": 180.0,
        "categoria": "Tours"
      },
      {
        "id": 3,
        "titulo": "Tiwanaku",
        "precio_usd": 90.0,
        "categoria": "Tours"
      }
    ],
    "disponibilidad": {
      "cupos_restantes": 20,
      "esta_disponible": true,
      "porcentaje_ocupacion": 0.0
    },
    "precios": {
      "precio_final_usd": 850.0,
      "precio_bob": 5865.0,
      "descuento_aplicado": 0
    }
  }
]
```

#### **Paquetes Destacados - Para Homepage**

```http
GET /api/paquetes/destacados/
```

#### **Paquetes Disponibles - Para Búsquedas**

```http
GET /api/paquetes/disponibles/
```

#### **Itinerario Detallado - Para Página de Producto**

```http
GET /api/paquetes/1/itinerario/
```

**Respuesta:**

```json
{
  "paquete_id": 1,
  "paquete_nombre": "Full Tour Bolivia - Experiencia Completa",
  "duracion_total": "5 días, 4 noches",
  "itinerario": [
    {
      "dia": 1,
      "actividades": [
        {
          "titulo": "Salar de Uyuni",
          "hora_inicio": "08:00:00",
          "hora_fin": "18:00:00",
          "punto_encuentro": "Uyuni, Potosí",
          "descripcion": "Experiencia única en el salar más grande del mundo..."
        }
      ]
    },
    {
      "dia": 2,
      "actividades": [
        {
          "titulo": "Isla del Sol",
          "hora_inicio": "08:00:00",
          "hora_fin": "18:00:00",
          "punto_encuentro": "Copacabana, La Paz"
        }
      ]
    }
  ]
}
```

### 🔍 **Filtros Útiles para Paquetes**

```javascript
// Paquetes por precio
GET /api/paquetes/?precio_min=200&precio_max=600

// Solo disponibles para reservar
GET /api/paquetes/?disponible=true

// Paquetes destacados activos
GET /api/paquetes/?destacado=true&activo=true

// Paquetes por duración
GET /api/paquetes/?duracion=día           // Tours de 1 día
GET /api/paquetes/?duracion=días          // Tours multi-día
```

---

## 🏕️ **SERVICIOS/DESTINOS - Actividades Individuales**

### 🎯 **¿Qué son los Servicios/Destinos?**

Destinos o actividades individuales que pueden reservarse por separado o formar parte de paquetes.

**Ejemplos reales:**

- **"Salar de Uyuni"** (destino individual - $250)
- **"Isla del Sol"** (destino individual - $180)
- **"Tiwanaku"** (destino individual - $90)
- **"Cristo de la Concordia"** (destino individual - $60)

### 🔗 **Endpoints de Servicios/Destinos**

#### **Listar Todos los Destinos**

```http
GET /api/servicios/
```

**Respuesta (ejemplo):**

```json
[
  {
    "id": 1,
    "titulo": "Salar de Uyuni",
    "descripcion": "Experiencia única en el salar más grande del mundo con paisajes espectaculares",
    "duracion": "1 día",
    "capacidad_max": 8,
    "punto_encuentro": "Uyuni, Potosí",
    "precio_usd": "250.00",
    "precio_bob": "1725.00",
    "categoria": {
      "id": 1,
      "nombre": "Tours",
      "descripcion": "Tours turísticos generales"
    },
    "imagen_url": "https://example.com/salar-uyuni.jpg",
    "estado": "Activo",
    "servicios_incluidos": ["Transporte 4x4", "Almuerzo", "Guía especializado"]
  },
  {
    "id": 2,
    "titulo": "Isla del Sol",
    "descripcion": "Descubre la cuna del Imperio Inca en el místico Lago Titicaca",
    "duracion": "1 día",
    "capacidad_max": 15,
    "punto_encuentro": "Copacabana, La Paz",
    "precio_usd": "180.00",
    "precio_bob": "1242.00",
    "categoria": {
      "id": 1,
      "nombre": "Tours"
    },
    "estado": "Activo"
  }
]
```

#### **Ver Destino Específico**

```http
GET /api/servicios/1/
```

### 🔍 **Filtros Útiles para Destinos**

```javascript
// Solo destinos activos
GET /api/servicios/?estado=Activo

// Por rango de precio
GET /api/servicios/?precio_usd__gte=100&precio_usd__lte=300

// Buscar destinos específicos
GET /api/servicios/?titulo__icontains=salar    // "Salar de Uyuni"
GET /api/servicios/?titulo__icontains=isla     // "Isla del Sol"

// Por categoría
GET /api/servicios/?categoria=1                // Tours

// Por capacidad
GET /api/servicios/?capacidad_max__gte=15      // Para grupos grandes
```

---

## 💻 **EJEMPLOS DE IMPLEMENTACIÓN FRONTEND**

### 🎨 **1. Página Principal - Carousel de Paquetes Destacados**

```javascript
// Obtener paquetes destacados para mostrar en homepage
async function cargarPaquetesDestacados() {
  try {
    const response = await fetch("/api/paquetes/destacados/");
    const paquetes = await response.json();

    // Renderizar carousel con máximo 6 paquetes
    renderCarouselPaquetes(paquetes);
  } catch (error) {
    console.error("Error cargando paquetes destacados:", error);
  }
}

function renderCarouselPaquetes(paquetes) {
  const carousel = document.getElementById("paquetes-carousel");

  paquetes.forEach((paquete) => {
    const slide = `
            <div class="carousel-slide">
                <img src="${paquete.imagen_principal}" alt="${paquete.nombre}">
                <div class="info">
                    <h3>${paquete.nombre}</h3>
                    <p class="duracion">${paquete.duracion}</p>
                    <p class="precio">$${paquete.precios.precio_final_usd} USD</p>
                    <p class="servicios">${paquete.servicios_incluidos.length} destinos incluidos</p>
                    <button onclick="verPaquete(${paquete.id})">Ver Detalle</button>
                </div>
            </div>
        `;
    carousel.innerHTML += slide;
  });
}
```

### 🎨 **2. Catálogo de Paquetes con Filtros**

```javascript
// Búsqueda de paquetes con filtros
async function buscarPaquetes() {
  const filtros = new URLSearchParams();

  // Obtener valores de filtros
  const precioMin = document.getElementById("precio-min").value;
  const precioMax = document.getElementById("precio-max").value;
  const duracion = document.getElementById("duracion").value;
  const disponible = document.getElementById("solo-disponibles").checked;

  // Agregar filtros si tienen valor
  if (precioMin) filtros.append("precio_min", precioMin);
  if (precioMax) filtros.append("precio_max", precioMax);
  if (duracion) filtros.append("duracion", duracion);
  if (disponible) filtros.append("disponible", "true");

  try {
    const response = await fetch(`/api/paquetes/?${filtros}`);
    const paquetes = await response.json();

    renderCatalogoPaquetes(paquetes);
  } catch (error) {
    console.error("Error en búsqueda:", error);
  }
}

function renderCatalogoPaquetes(paquetes) {
  const catalogo = document.getElementById("catalogo-paquetes");

  if (paquetes.length === 0) {
    catalogo.innerHTML = "<p>No se encontraron paquetes con esos filtros</p>";
    return;
  }

  catalogo.innerHTML = "";
  paquetes.forEach((paquete) => {
    const card = `
            <div class="paquete-card ${paquete.destacado ? "destacado" : ""}">
                <img src="${paquete.imagen_principal}" alt="${paquete.nombre}">
                <div class="info">
                    <h3>${paquete.nombre}</h3>
                    <p class="descripcion">${paquete.descripcion.substring(
                      0,
                      150
                    )}...</p>
                    <div class="detalles">
                        <span class="duracion">⏱️ ${paquete.duracion}</span>
                        <span class="destinos">🏕️ ${
                          paquete.servicios_incluidos.length
                        } destinos</span>
                    </div>
                    <div class="precios">
                        <span class="precio-usd">$${
                          paquete.precios.precio_final_usd
                        } USD</span>
                        <span class="precio-bob">Bs. ${
                          paquete.precios.precio_bob
                        }</span>
                    </div>
                    <div class="disponibilidad">
                        <span class="cupos">${
                          paquete.disponibilidad.cupos_restantes
                        } cupos disponibles</span>
                        <div class="ocupacion-bar">
                            <div class="ocupacion-fill" style="width: ${
                              paquete.disponibilidad.porcentaje_ocupacion
                            }%"></div>
                        </div>
                    </div>
                    <button onclick="verPaqueteDetalle(${
                      paquete.id
                    })" class="btn-ver-detalle">
                        Ver Itinerario Completo
                    </button>
                </div>
            </div>
        `;
    catalogo.innerHTML += card;
  });
}
```

### 🎨 **3. Página de Detalle de Paquete**

```javascript
// Cargar información completa del paquete + itinerario
async function cargarPaqueteDetalle(paqueteId) {
  try {
    // Cargar información básica e itinerario en paralelo
    const [paqueteResponse, itinerarioResponse] = await Promise.all([
      fetch(`/api/paquetes/${paqueteId}/`),
      fetch(`/api/paquetes/${paqueteId}/itinerario/`),
    ]);

    const paquete = await paqueteResponse.json();
    const itinerario = await itinerarioResponse.json();

    renderPaqueteDetalle(paquete);
    renderItinerario(itinerario);
  } catch (error) {
    console.error("Error cargando paquete:", error);
  }
}

function renderItinerario(itinerarioData) {
  const container = document.getElementById("itinerario-container");

  itinerarioData.itinerario.forEach((dia) => {
    const diaElement = `
            <div class="dia-itinerario">
                <h4>Día ${dia.dia}</h4>
                <div class="actividades">
                    ${dia.actividades
                      .map(
                        (actividad) => `
                        <div class="actividad">
                            <div class="horario">
                                <span>${actividad.hora_inicio} - ${
                          actividad.hora_fin
                        }</span>
                            </div>
                            <div class="detalles">
                                <h5>${actividad.titulo}</h5>
                                <p>${actividad.descripcion}</p>
                                <p class="punto-encuentro">📍 ${
                                  actividad.punto_encuentro
                                }</p>
                                ${
                                  actividad.notas
                                    ? `<p class="notas">${actividad.notas}</p>`
                                    : ""
                                }
                            </div>
                        </div>
                    `
                      )
                      .join("")}
                </div>
            </div>
        `;
    container.innerHTML += diaElement;
  });
}
```

### 🎨 **4. Búsqueda de Destinos Individuales**

```javascript
// Para mostrar destinos como alternativas o complementos
async function cargarDestinosIndividuales() {
  try {
    const response = await fetch("/api/servicios/?estado=Activo");
    const destinos = await response.json();

    renderDestinosIndividuales(destinos);
  } catch (error) {
    console.error("Error cargando destinos:", error);
  }
}

function renderDestinosIndividuales(destinos) {
  const container = document.getElementById("destinos-individuales");

  destinos.forEach((destino) => {
    const card = `
            <div class="destino-card">
                <img src="${destino.imagen_url}" alt="${destino.titulo}">
                <div class="info">
                    <h4>${destino.titulo}</h4>
                    <p class="categoria">${destino.categoria.nombre}</p>
                    <p class="duracion">⏱️ ${destino.duracion}</p>
                    <p class="capacidad">👥 Hasta ${
                      destino.capacidad_max
                    } personas</p>
                    <div class="servicios-incluidos">
                        <h5>Incluye:</h5>
                        <ul>
                            ${destino.servicios_incluidos
                              .map((servicio) => `<li>${servicio}</li>`)
                              .join("")}
                        </ul>
                    </div>
                    <div class="precios">
                        <span class="precio">$${destino.precio_usd} USD</span>
                        <span class="precio-bob">Bs. ${
                          destino.precio_bob
                        }</span>
                    </div>
                    <button onclick="reservarDestino(${
                      destino.id
                    })">Reservar Solo Este Destino</button>
                </div>
            </div>
        `;
    container.innerHTML += card;
  });
}
```

---

## 📊 **CASOS DE USO RECOMENDADOS**

### ✅ **Usar API de Paquetes cuando:**

- Mostrar ofertas completas en homepage
- Catálogo principal de experiencias
- Usuario busca vacaciones completas
- Mostrar itinerarios organizados
- Cálculos de precios con descuentos

### ✅ **Usar API de Servicios cuando:**

- Mostrar destinos individuales
- Usuario busca actividad específica
- Comparar precios por destino
- Crear paquetes personalizados
- Mostrar alternativas o add-ons

### 🔄 **Combinar ambas APIs para:**

- Mostrar "Otros destinos disponibles" en página de paquete
- Sugerir destinos individuales como complemento
- Permitir personalización de paquetes existentes
- Comparar precios: paquete vs destinos por separado

---

## 🚀 **URLs de Prueba Directa**

### 📦 **Paquetes Turísticos:**

- **Lista completa:** http://127.0.0.1:8000/api/paquetes/
- **Destacados:** http://127.0.0.1:8000/api/paquetes/destacados/
- **Disponibles:** http://127.0.0.1:8000/api/paquetes/disponibles/
- **Detalle paquete:** http://127.0.0.1:8000/api/paquetes/1/
- **Itinerario:** http://127.0.0.1:8000/api/paquetes/1/itinerario/

### 🏕️ **Servicios/Destinos:**

- **Lista completa:** http://127.0.0.1:8000/api/servicios/
- **Destinos activos:** http://127.0.0.1:8000/api/servicios/?estado=Activo
- **Por precio:** http://127.0.0.1:8000/api/servicios/?precio_usd__lte=200
- **Buscar Salar:** http://127.0.0.1:8000/api/servicios/?titulo__icontains=salar
- **Categorías:** http://127.0.0.1:8000/api/categorias/
