# 🔄 Sistema de Reprogramación - Pruebas Postman

## 📋 Endpoints Disponibles

### 1. **⚙️ Configuración Global**

#### **Listar Configuraciones**
```http
GET /configuracion-global-reprogramacion/
Authorization: Bearer {access_token}
```

#### **Crear Nueva Configuración**
```http
POST /configuracion-global-reprogramacion/
Content-Type: application/json
Authorization: Bearer {access_token}

{
    "clave": "costo_reprogramacion_minimo",
    "valor": "25.00",
    "tipo_valor": "DECIMAL",
    "activa": true,
    "descripcion": "Costo mínimo por reprogramar una reserva"
}
```

#### **Actualizar Configuración**
```http
PUT /configuracion-global-reprogramacion/1/
Content-Type: application/json
Authorization: Bearer {access_token}

{
    "clave": "max_reprogramaciones_por_reserva",
    "valor": "5", 
    "tipo_valor": "INTEGER",
    "activa": true,
    "descripcion": "Nuevo límite de reprogramaciones"
}
```

### 2. **📏 Reglas de Reprogramación**

#### **Listar Reglas**
```http
GET /reglas-reprogramacion/
Authorization: Bearer {access_token}
```

#### **Crear Regla de Tiempo Mínimo**
```http
POST /reglas-reprogramacion/
Content-Type: application/json
Authorization: Bearer {access_token}

{
    "nombre": "Servicios Premium - 48h",
    "descripcion": "Servicios premium requieren 48 horas de anticipación",
    "tipo_regla": "TIEMPO_MINIMO",
    "aplicable_a": "CLIENTE",
    "limite_hora": 48,
    "valor_numerico": 48,
    "condiciones": "{\"categoria\": \"Premium\", \"horas_minimas\": 48}",
    "prioridad": 5,
    "activa": true
}
```

#### **Crear Regla de Penalización**
```http
POST /reglas-reprogramacion/
Content-Type: application/json
Authorization: Bearer {access_token}

{
    "nombre": "Penalización Fin de Semana",
    "descripcion": "10% de penalización para reprogramaciones en fin de semana",
    "tipo_regla": "DESCUENTO_PENALIZACION",
    "aplicable_a": "ALL",
    "valor_decimal": "0.10",
    "condiciones": "{\"dias\": [\"saturday\", \"sunday\"], \"porcentaje\": 10}",
    "prioridad": 3,
    "activa": true
}
```

#### **Crear Regla de Días Blackout**
```http
POST /reglas-reprogramacion/
Content-Type: application/json
Authorization: Bearer {access_token}

{
    "nombre": "Días No Permitidos",
    "descripcion": "Fechas especiales donde no se permite reprogramar",
    "tipo_regla": "DIAS_BLACKOUT", 
    "aplicable_a": "ALL",
    "valor_texto": "2025-12-25,2025-01-01,2025-02-14",
    "condiciones": "{\"fechas_bloqueadas\": [\"2025-12-25\", \"2025-01-01\"]}",
    "prioridad": 10,
    "activa": true
}
```

### 3. **📜 Historial de Reprogramación**

#### **Listar Historial**
```http
GET /historial-reprogramacion/
Authorization: Bearer {access_token}
```

#### **Registrar Nueva Reprogramación**
```http
POST /historial-reprogramacion/
Content-Type: application/json
Authorization: Bearer {access_token}

{
    "reserva": 1,
    "fecha_anterior": "2025-01-15T10:00:00Z",
    "fecha_nueva": "2025-01-22T10:00:00Z",
    "motivo": "Cliente solicitó cambio por viaje de trabajo",
    "reprogramado_por": 2,
    "notificacion_enviada": true
}
```

#### **Ver Historial de una Reserva Específica**
```http
GET /historial-reprogramacion/?reserva=1
Authorization: Bearer {access_token}
```

### 4. **🧾 Reservas con Reprogramación**

#### **Actualizar Reserva (Reprogramar)**
```http
PUT /reservas/1/
Content-Type: application/json
Authorization: Bearer {access_token}

{
    "fecha": "2025-02-20",
    "fecha_inicio": "2025-02-20T09:00:00Z",
    "fecha_fin": "2025-02-20T17:00:00Z",
    "estado": "REPROGRAMADA",
    "total": "850.00",
    "cliente": 2,
    "cupon": null,
    "fecha_original": "2025-02-15T09:00:00Z",
    "fecha_reprogramacion": "2025-01-10T14:30:00Z",
    "numero_reprogramaciones": 1,
    "motivo_reprogramacion": "Cambio de fecha por disponibilidad del cliente",
    "reprogramado_por": 1
}
```

## 📊 Tipos de Reglas Disponibles

| Tipo | Descripción | Campos Útiles |
|------|-------------|---------------|
| `TIEMPO_MINIMO` | Tiempo mínimo de anticipación | `limite_hora`, `valor_numerico` |
| `TIEMPO_MAXIMO` | Tiempo máximo para reprogramar | `limite_hora`, `valor_numerico` |
| `LIMITE_REPROGRAMACIONES` | Max reprogramaciones por reserva | `valor_numerico` |
| `LIMITE_DIARIO` | Límite diario por usuario | `valor_numerico` |
| `DIAS_BLACKOUT` | Días no permitidos | `valor_texto` |
| `HORAS_BLACKOUT` | Horas no permitidas | `valor_texto` |
| `SERVICIOS_RESTRINGIDOS` | Servicios con restricciones | `valor_texto`, `condiciones` |
| `CAPACIDAD_MAXIMA` | Límite de capacidad por fecha | `valor_numerico` |
| `DESCUENTO_PENALIZACION` | Penalización por reprogramar | `valor_decimal` |

## 🎯 Aplicabilidad de Reglas

- `ALL`: Todos los usuarios
- `CLIENTE`: Solo clientes
- `ADMIN`: Solo administradores  
- `OPERADOR`: Solo operadores

## 📈 Casos de Uso de Prueba

### **Escenario 1: Cliente VIP**
1. Crear regla para clientes con +5 viajes
2. Permitir reprogramación sin penalización
3. Registrar historial de cambio

### **Escenario 2: Servicio Premium** 
1. Crear regla para servicios >$500
2. Requerir 48h de anticipación
3. Aplicar penalización del 5%

### **Escenario 3: Temporada Alta**
1. Crear días blackout (Dic 20-31)
2. Limitar reprogramaciones a 1 por reserva
3. Aumentar costo de reprogramación

---
*Este es el sistema más avanzado - ideal para probar todas las funcionalidades nuevas.*