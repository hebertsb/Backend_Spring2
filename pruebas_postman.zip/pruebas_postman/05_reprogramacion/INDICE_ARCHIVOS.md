# 📋 ÍNDICE DE ARCHIVOS - SISTEMA DE REPROGRAMACIÓN

## 📁 Contenido de la Carpeta

```
05_reprogramacion/
├── 📖 GUIA_TECNICA_FRONTEND.txt              # Para el equipo de frontend
├── 🧪 Sistema_Reprogramacion.postman_collection.json  # Colección completa
├── ⚙️ Reprogramacion_Environment.postman_environment.json  # Variables de entorno
├── 📋 GUIA_TESTING_POSTMAN.txt               # Instrucciones paso a paso
└── 📝 guia_reprogramacion_avanzada.md        # Guía markdown (ya existía)
```

## 🎯 Uso de cada Archivo

### **1. GUIA_TECNICA_FRONTEND.txt**

- **Para:** Desarrollador Frontend / Agent
- **Contiene:**
  - Documentación completa de la API
  - Todos los endpoints con ejemplos
  - Códigos de error y respuestas
  - Campos y validaciones
  - Flujo recomendado de integración

### **2. Sistema_Reprogramacion.postman_collection.json**

- **Para:** Testing y QA
- **Contiene:**
  - 20+ requests organizados por funcionalidad
  - Tests automáticos incluidos
  - Variables que se auto-completan
  - Ejemplos de payloads realistas
  - Validaciones de respuestas

### **3. Reprogramacion_Environment.postman_environment.json**

- **Para:** Configuración de Postman
- **Contiene:**
  - URL base del servidor local
  - Variables para tokens y IDs
  - Configuración lista para importar

### **4. GUIA_TESTING_POSTMAN.txt**

- **Para:** Tester manual
- **Contiene:**
  - Instrucciones paso a paso
  - Orden de ejecución de pruebas
  - Casos de error a validar
  - Códigos HTTP esperados
  - Tips de debugging

## 🚀 Cómo Usar

### **Paso 1: Importar en Postman**

1. Abrir Postman
2. File > Import
3. Arrastrar ambos archivos JSON
4. Seleccionar environment "Reprogramacion Local"

### **Paso 2: Verificar Servidor**

```bash
python manage.py runserver
# Debe estar corriendo en http://127.0.0.1:8000
```

### **Paso 3: Ejecutar Pruebas**

1. Ejecutar "Login Admin" primero
2. Seguir el orden de las carpetas (01, 02, 03...)
3. Revisar Test Results después de cada request

### **Paso 4: Para el Frontend**

- Entregar `GUIA_TECNICA_FRONTEND.txt`
- Mostrar ejemplos con Postman si es necesario
- El archivo tiene toda la documentación técnica

## 📊 Funcionalidades Cubiertas

✅ **Configuración Global**: CRUD completo
✅ **Reglas de Reprogramación**: 9 tipos diferentes  
✅ **Historial**: Auditoría completa
✅ **Reservas**: Integración con reprogramación
✅ **Autenticación**: JWT tokens
✅ **Tests Automatizados**: Validaciones incluidas

## 🔧 Endpoints Implementados

| Endpoint                                | Métodos                | Descripción                 |
| --------------------------------------- | ---------------------- | --------------------------- |
| `/configuracion-global-reprogramacion/` | GET, POST, PUT, DELETE | Configuraciones del sistema |
| `/reglas-reprogramacion/`               | GET, POST, PUT, DELETE | Reglas de negocio           |
| `/historial-reprogramacion/`            | GET, POST, PUT, DELETE | Auditoría de cambios        |
| `/reservas/`                            | GET, POST, PUT, DELETE | Reservas con reprogramación |

## 💡 Casos de Uso Implementados

1. **Cliente VIP**: Reglas especiales con menos restricciones
2. **Temporada Alta**: Días blackout y penalizaciones
3. **Servicios Premium**: Reglas por tipo de servicio
4. **Límites Globales**: Configuraciones aplicables a todos
5. **Auditoría Completa**: Historial de todos los cambios

---

_Todos los archivos están excluidos de Git según el .gitignore_
