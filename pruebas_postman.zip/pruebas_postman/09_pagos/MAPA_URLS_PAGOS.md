# 🗺️ Mapa de URLs - Pagos

- `POST /api/pagos/` — Crear pago real (Stripe)
- `GET /api/pagos/` — Listar pagos
- `GET /api/pagos/{id}/` — Detalle de pago

## Flujo sugerido

1. El usuario reserva.
2. El frontend inicia el pago con Stripe.
3. Al finalizar, registra el pago real en el backend.
4. El backend responde con el estado y datos del pago.
