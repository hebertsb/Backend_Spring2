# 💳 API de Pagos con Stripe

## Endpoints principales

- `POST /api/pagos/` — Crear un pago real (Stripe)
- `GET /api/pagos/` — Listar pagos
- `GET /api/pagos/{id}/` — Detalle de pago

## Ejemplo de JSON para crear pago

```json
{
  "reserva_id": 35,
  "monto": 828.0,
  "metodo": "Tarjeta",
  "fecha_pago": "2025-10-14",
  "estado": "Confirmado",
  "url_stripe": "https://stripe.com/checkout/session/test"
}
```

## Respuesta exitosa

```json
{
  "id": 11,
  "reserva": { ... },
  "monto": "828.00",
  "metodo": "Tarjeta",
  "fecha_pago": "2025-10-14",
  "estado": "Confirmado",
  "url_stripe": "https://stripe.com/checkout/session/test"
}
```

## Notas importantes

- El campo `url_stripe` debe ser una URL válida.
- Los valores válidos para `metodo` son: "Tarjeta", "Transferencia", "Efectivo".
- Los valores válidos para `estado` son: "Confirmado", "Pendiente", "Fallido".
- El campo `reserva_id` debe ser el ID de una reserva existente.

---

# 🧪 Pruebas recomendadas (Postman)

1. Crear pago real con Stripe (ver ejemplo arriba)
2. Listar pagos y verificar que el pago aparece
3. Consultar detalle de pago por ID

---

# 🗺️ Mapa de URLs de Pagos

- `POST /api/pagos/` — Crear pago
- `GET /api/pagos/` — Listar pagos
- `GET /api/pagos/{id}/` — Detalle de pago

---

# 🚦 Flujo recomendado para el frontend

1. El usuario realiza una reserva.
2. El frontend redirige o muestra el checkout de Stripe.
3. Al completar el pago, se registra el pago real usando el endpoint `/api/pagos/`.
4. El backend valida y almacena el pago.
5. El frontend puede consultar el estado del pago y mostrar confirmación al usuario.

---

# ⚠️ Importante

- El endpoint de pago simulado ha sido eliminado. Solo se aceptan pagos reales vía Stripe.
