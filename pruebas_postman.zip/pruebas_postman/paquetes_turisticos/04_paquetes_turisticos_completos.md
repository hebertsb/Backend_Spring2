# 📦 API de Paquetes Turísticos - Guía Completa

## 🎯 Descripción

Nueva implementación de paquetes turísticos reales que combinan múltiples destinos/servicios en un solo paquete. Reemplaza el sistema anterior basado en campañas por un modelo dedicado específicamente para paquetes turísticos.

## 🔗 Endpoints Principales

### 1. **Listar Todos los Paquetes**

```http
GET /api/paquetes/
```

**Respuesta:**

```json
[
  {
    "id": 1,
    "nombre": "Full Tour Bolivia - Experiencia Completa",
    "descripcion": "El paquete más completo para conocer los principales atractivos turísticos de Bolivia...",
    "duracion": "5 días, 4 noches",
    "precio_base": "850.00",
    "precio_bob": "5865.00",
    "cupos_disponibles": 20,
    "cupos_ocupados": 0,
    "fecha_inicio": "2024-01-15",
    "fecha_fin": "2024-04-15",
    "estado": "Activo",
    "destacado": true,
    "imagen_principal": "https://example.com/full-tour-bolivia.jpg",
    "punto_salida": "Plaza Murillo, La Paz",
    "incluye": [
      "Transporte terrestre y aéreo",
      "Alojamiento en hoteles 3 estrellas",
      "Desayuno, almuerzo y cena",
      "Guía turístico especializado",
      "Entradas a todos los sitios",
      "Seguro de viaje"
    ],
    "no_incluye": [
      "Gastos personales",
      "Bebidas alcohólicas",
      "Propinas",
      "Actividades opcionales no mencionadas"
    ],
    "servicios_incluidos": [
      {
        "id": 1,
        "titulo": "Salar de Uyuni",
        "descripcion": "Experiencia única en el salar más grande del mundo...",
        "categoria": "Tours",
        "imagen_url": "https://example.com/salar-uyuni.jpg",
        "precio_usd": 250.0
      },
      {
        "id": 2,
        "titulo": "Isla del Sol",
        "descripcion": "Descubre la cuna del Imperio Inca...",
        "categoria": "Tours",
        "imagen_url": "https://example.com/isla-sol.jpg",
        "precio_usd": 180.0
      }
    ],
    "itinerario": [
      {
        "dia": 1,
        "actividades": [
          {
            "orden": 1,
            "hora_inicio": "08:00:00",
            "hora_fin": "18:00:00",
            "titulo": "Salar de Uyuni",
            "descripcion": "Tour completo por el salar...",
            "punto_encuentro": "Uyuni, Potosí",
            "notas": "Día 1: Salar de Uyuni",
            "categoria": "Tours"
          }
        ]
      }
    ],
    "precios": {
      "precio_original_usd": 850.0,
      "precio_final_usd": 850.0,
      "precio_bob": 5865.0,
      "descuento_aplicado": 0,
      "porcentaje_descuento": 0
    },
    "disponibilidad": {
      "cupos_disponibles": 20,
      "cupos_ocupados": 0,
      "cupos_restantes": 20,
      "porcentaje_ocupacion": 0.0,
      "esta_vigente": true,
      "esta_disponible": true,
      "fecha_inicio": "2024-01-15",
      "fecha_fin": "2024-04-15"
    },
    "campania_info": null,
    "created_at": "2024-01-15T10:30:00Z"
  }
]
```

### 2. **Ver Detalle de un Paquete**

```http
GET /api/paquetes/{id}/
```

### 3. **Paquetes Destacados**

```http
GET /api/paquetes/destacados/
```

### 4. **Paquetes Disponibles**

```http
GET /api/paquetes/disponibles/
```

### 5. **Itinerario Detallado**

```http
GET /api/paquetes/{id}/itinerario/
```

**Respuesta:**

```json
{
  "paquete_id": 1,
  "paquete_nombre": "Full Tour Bolivia - Experiencia Completa",
  "duracion_total": "5 días, 4 noches",
  "itinerario": [
    {
      "dia": 1,
      "fecha_ejemplo": null,
      "actividades": [
        {
          "id": 1,
          "orden": 1,
          "hora_inicio": "08:00:00",
          "hora_fin": "18:00:00",
          "servicio_id": 1,
          "titulo": "Salar de Uyuni",
          "descripcion": "Experiencia única en el salar más grande del mundo...",
          "categoria": "Tours",
          "punto_encuentro": "Uyuni, Potosí",
          "notas": "Día 1: Salar de Uyuni",
          "servicios_incluidos": [
            "Transporte 4x4",
            "Almuerzo",
            "Guía especializado"
          ]
        }
      ]
    }
  ]
}
```

## 🔍 Parámetros de Filtrado

### Filtros Disponibles en `/api/paquetes/`

| Parámetro    | Descripción                             | Ejemplo            |
| ------------ | --------------------------------------- | ------------------ |
| `activo`     | Solo paquetes activos                   | `?activo=true`     |
| `disponible` | Solo paquetes disponibles para reservar | `?disponible=true` |
| `destacado`  | Solo paquetes destacados                | `?destacado=true`  |
| `precio_min` | Precio mínimo en USD                    | `?precio_min=100`  |
| `precio_max` | Precio máximo en USD                    | `?precio_max=500`  |
| `duracion`   | Buscar en duración (contiene)           | `?duracion=día`    |

### Ejemplos de Uso:

```http
# Paquetes activos y disponibles
GET /api/paquetes/?activo=true&disponible=true

# Paquetes entre $200-$600
GET /api/paquetes/?precio_min=200&precio_max=600

# Paquetes de 1 día
GET /api/paquetes/?duracion=1%20día

# Paquetes destacados activos
GET /api/paquetes/?destacado=true&activo=true
```

## 📊 Estructura de Datos

### Modelo Paquete

- **Información básica:** nombre, descripción, duración
- **Precios:** precio_base (USD), precio_bob, con soporte para descuentos por campaña
- **Disponibilidad:** cupos totales, ocupados, fechas de vigencia
- **Estado:** Activo/Inactivo/Agotado
- **Configuración:** destacado, imagen principal, punto de salida
- **Servicios incluidos:** relación many-to-many con modelo Servicio
- **Itinerario:** organizado por días con horarios específicos

### Campos Calculados

- `cupos_restantes`: Cupos disponibles - cupos ocupados
- `porcentaje_ocupacion`: % de ocupación actual
- `precio_con_descuento`: Precio final aplicando campaña si existe
- `esta_vigente`: Si está dentro del rango de fechas
- `esta_disponible`: Si está activo, vigente y con cupos

## 🎯 Casos de Uso Frontend

### 1. **Página Principal - Paquetes Destacados**

```javascript
// Obtener paquetes destacados para carousel/grid principal
fetch("/api/paquetes/destacados/")
  .then((response) => response.json())
  .then((paquetes) => {
    // Mostrar hasta 6 paquetes destacados
    renderPaquetesDestacados(paquetes);
  });
```

### 2. **Catálogo de Paquetes con Filtros**

```javascript
// Búsqueda con filtros dinámicos
const filtros = new URLSearchParams({
  activo: "true",
  precio_min: document.getElementById("precioMin").value,
  precio_max: document.getElementById("precioMax").value,
  duracion: document.getElementById("duracion").value,
});

fetch(`/api/paquetes/?${filtros}`)
  .then((response) => response.json())
  .then((paquetes) => {
    renderCatalogoPaquetes(paquetes);
  });
```

### 3. **Página de Detalle del Paquete**

```javascript
// Información completa + itinerario
Promise.all([
  fetch(`/api/paquetes/${paqueteId}/`),
  fetch(`/api/paquetes/${paqueteId}/itinerario/`),
])
  .then(([paqueteResponse, itinerarioResponse]) => {
    return Promise.all([paqueteResponse.json(), itinerarioResponse.json()]);
  })
  .then(([paquete, itinerario]) => {
    renderDetallePaquete(paquete);
    renderItinerario(itinerario);
  });
```

### 4. **Verificación de Disponibilidad**

```javascript
// Antes de proceder a reservar
fetch(`/api/paquetes/${paqueteId}/`)
  .then((response) => response.json())
  .then((paquete) => {
    if (paquete.disponibilidad.esta_disponible) {
      // Proceder con reserva
      showReservaForm();
    } else {
      // Mostrar mensaje de no disponibilidad
      showUnavailableMessage(paquete.disponibilidad);
    }
  });
```

## ⚠️ Consideraciones Importantes

### 1. **Migración desde Sistema Anterior**

- Los endpoints `/api/paquetes/` ahora retornan el nuevo modelo Paquete
- El sistema anterior de Campaña sigue funcionando en `/api/campanias/`
- Los paquetes pueden asociarse opcionalmente a campañas para descuentos

### 2. **Relación con Reservas**

- Las reservas existentes seguirán funcionando
- Nuevas reservas pueden referenciar paquetes completos
- El sistema calcula precios automáticamente con descuentos aplicados

### 3. **Gestión de Cupos**

- Los cupos se manejan a nivel de paquete completo
- Cada servicio individual mantiene su propia capacidad
- El sistema debe verificar disponibilidad en ambos niveles

### 4. **URLs Compatibles**

- `/api/paquetes/` - Nueva implementación con paquetes reales
- `/api/campanias/` - Sistema anterior (mantenido para compatibilidad)
- URLs específicas como `/destacados/` y `/disponibles/` para casos comunes

## 🚀 Siguientes Pasos

1. **Actualizar Frontend:** Cambiar llamadas API para usar nueva estructura
2. **Gestión Admin:** Crear interfaz para administrar paquetes y itinerarios
3. **Sistema de Reservas:** Integrar reservas con el nuevo modelo de paquetes
4. **Optimizaciones:** Implementar caché y optimizaciones de consultas

## 🔗 Enlaces Relacionados

- [API Reservas Cliente](/api/reservas/mis_reservas/) - Ver reservas del usuario
- [API Perfil Usuario](/api/perfil/mi_perfil/) - Información del cliente
- [API Servicios](/api/servicios/) - Servicios individuales disponibles
