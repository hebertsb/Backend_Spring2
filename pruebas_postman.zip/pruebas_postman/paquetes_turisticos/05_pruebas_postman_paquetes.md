# 🧪 Pruebas Postman - Paquetes Turísticos

## 📋 Collection: Paquetes Turísticos API

### 🔧 Variables de Entorno

```json
{
  "base_url": "http://localhost:8000/api",
  "paquete_id": "1"
}
```

### 📦 1. Listar Todos los Paquetes

**Request:**

```
GET {{base_url}}/paquetes/
```

**Headers:**

```
Content-Type: application/json
```

**Tests:**

```javascript
pm.test("Status code is 200", function () {
  pm.response.to.have.status(200);
});

pm.test("Response is an array", function () {
  const responseJson = pm.response.json();
  pm.expect(responseJson).to.be.an("array");
});

pm.test("Paquetes have required fields", function () {
  const responseJson = pm.response.json();
  if (responseJson.length > 0) {
    const paquete = responseJson[0];
    pm.expect(paquete).to.have.property("id");
    pm.expect(paquete).to.have.property("nombre");
    pm.expect(paquete).to.have.property("precio_base");
    pm.expect(paquete).to.have.property("duracion");
    pm.expect(paquete).to.have.property("servicios_incluidos");
    pm.expect(paquete).to.have.property("itinerario");
    pm.expect(paquete).to.have.property("disponibilidad");
  }
});

// Guardar ID del primer paquete para pruebas siguientes
pm.test("Save first paquete ID", function () {
  const responseJson = pm.response.json();
  if (responseJson.length > 0) {
    pm.environment.set("paquete_id", responseJson[0].id.toString());
  }
});
```

### 📦 2. Obtener Paquete por ID

**Request:**

```
GET {{base_url}}/paquetes/{{paquete_id}}/
```

**Tests:**

```javascript
pm.test("Status code is 200", function () {
  pm.response.to.have.status(200);
});

pm.test("Paquete has complete structure", function () {
  const paquete = pm.response.json();

  // Campos básicos
  pm.expect(paquete).to.have.property("id");
  pm.expect(paquete).to.have.property("nombre");
  pm.expect(paquete).to.have.property("descripcion");
  pm.expect(paquete).to.have.property("duracion");

  // Precios
  pm.expect(paquete).to.have.property("precio_base");
  pm.expect(paquete.precios).to.have.property("precio_original_usd");
  pm.expect(paquete.precios).to.have.property("precio_final_usd");

  // Disponibilidad
  pm.expect(paquete.disponibilidad).to.have.property("cupos_disponibles");
  pm.expect(paquete.disponibilidad).to.have.property("cupos_restantes");
  pm.expect(paquete.disponibilidad).to.have.property("esta_disponible");

  // Servicios e itinerario
  pm.expect(paquete.servicios_incluidos).to.be.an("array");
  pm.expect(paquete.itinerario).to.be.an("array");
});

pm.test("Servicios incluidos have correct structure", function () {
  const paquete = pm.response.json();
  if (paquete.servicios_incluidos.length > 0) {
    const servicio = paquete.servicios_incluidos[0];
    pm.expect(servicio).to.have.property("id");
    pm.expect(servicio).to.have.property("titulo");
    pm.expect(servicio).to.have.property("precio_usd");
  }
});
```

### 📦 3. Paquetes Destacados

**Request:**

```
GET {{base_url}}/paquetes/destacados/
```

**Tests:**

```javascript
pm.test("Status code is 200", function () {
  pm.response.to.have.status(200);
});

pm.test("All paquetes are destacados", function () {
  const paquetes = pm.response.json();
  paquetes.forEach((paquete) => {
    pm.expect(paquete.destacado).to.be.true;
  });
});

pm.test("Maximum 6 destacados returned", function () {
  const paquetes = pm.response.json();
  pm.expect(paquetes.length).to.be.at.most(6);
});
```

### 📦 4. Paquetes Disponibles

**Request:**

```
GET {{base_url}}/paquetes/disponibles/
```

**Tests:**

```javascript
pm.test("Status code is 200", function () {
  pm.response.to.have.status(200);
});

pm.test("All paquetes are available", function () {
  const paquetes = pm.response.json();
  paquetes.forEach((paquete) => {
    pm.expect(paquete.estado).to.equal("Activo");
    pm.expect(paquete.disponibilidad.esta_disponible).to.be.true;
    pm.expect(paquete.disponibilidad.cupos_restantes).to.be.above(0);
  });
});
```

### 📦 5. Itinerario Detallado

**Request:**

```
GET {{base_url}}/paquetes/{{paquete_id}}/itinerario/
```

**Tests:**

```javascript
pm.test("Status code is 200", function () {
  pm.response.to.have.status(200);
});

pm.test("Itinerario has correct structure", function () {
  const response = pm.response.json();

  pm.expect(response).to.have.property("paquete_id");
  pm.expect(response).to.have.property("paquete_nombre");
  pm.expect(response).to.have.property("duracion_total");
  pm.expect(response).to.have.property("itinerario");

  pm.expect(response.itinerario).to.be.an("array");

  if (response.itinerario.length > 0) {
    const dia = response.itinerario[0];
    pm.expect(dia).to.have.property("dia");
    pm.expect(dia).to.have.property("actividades");
    pm.expect(dia.actividades).to.be.an("array");

    if (dia.actividades.length > 0) {
      const actividad = dia.actividades[0];
      pm.expect(actividad).to.have.property("servicio_id");
      pm.expect(actividad).to.have.property("titulo");
      pm.expect(actividad).to.have.property("punto_encuentro");
    }
  }
});
```

### 📦 6. Filtros - Paquetes por Precio

**Request:**

```
GET {{base_url}}/paquetes/?precio_min=100&precio_max=500
```

**Tests:**

```javascript
pm.test("Status code is 200", function () {
  pm.response.to.have.status(200);
});

pm.test("All paquetes within price range", function () {
  const paquetes = pm.response.json();
  paquetes.forEach((paquete) => {
    const precio = parseFloat(paquete.precio_base);
    pm.expect(precio).to.be.at.least(100);
    pm.expect(precio).to.be.at.most(500);
  });
});
```

### 📦 7. Filtros - Solo Activos

**Request:**

```
GET {{base_url}}/paquetes/?activo=true
```

**Tests:**

```javascript
pm.test("Status code is 200", function () {
  pm.response.to.have.status(200);
});

pm.test("All paquetes are active", function () {
  const paquetes = pm.response.json();
  paquetes.forEach((paquete) => {
    pm.expect(paquete.estado).to.equal("Activo");
  });
});
```

### 📦 8. Filtros - Por Duración

**Request:**

```
GET {{base_url}}/paquetes/?duracion=día
```

**Tests:**

```javascript
pm.test("Status code is 200", function () {
  pm.response.to.have.status(200);
});

pm.test("All paquetes match duration filter", function () {
  const paquetes = pm.response.json();
  paquetes.forEach((paquete) => {
    pm.expect(paquete.duracion.toLowerCase()).to.include("día");
  });
});
```

## 🔄 Orden de Ejecución Recomendado

1. **Listar Todos los Paquetes** - Para obtener IDs y overview general
2. **Obtener Paquete por ID** - Para ver estructura completa
3. **Itinerario Detallado** - Para verificar datos de itinerario
4. **Paquetes Destacados** - Para verificar filtro de destacados
5. **Paquetes Disponibles** - Para verificar lógica de disponibilidad
6. **Filtros por Precio** - Para verificar filtrado por rangos
7. **Filtros por Estado** - Para verificar filtrado por activos
8. **Filtros por Duración** - Para verificar búsqueda de texto

## 📊 Verificaciones de Calidad

### ✅ Validaciones Básicas

- [ ] Todos los endpoints responden con status 200
- [ ] Las respuestas tienen estructura JSON válida
- [ ] Los campos requeridos están presentes
- [ ] Los tipos de datos son correctos

### ✅ Validaciones de Negocio

- [ ] Solo paquetes activos aparecen en `/disponibles/`
- [ ] Paquetes destacados tienen `destacado: true`
- [ ] Cálculos de disponibilidad son correctos
- [ ] Precios se muestran en USD y BOB
- [ ] Itinerarios están ordenados por día y orden

### ✅ Validaciones de Performance

- [ ] Tiempo de respuesta < 500ms para listados
- [ ] Tiempo de respuesta < 200ms para detalle
- [ ] Filtros funcionan sin timeouts
- [ ] Consultas optimizadas (verificar con Django Debug Toolbar)

## 🚨 Casos de Error a Probar

### 404 - Paquete No Encontrado

```
GET {{base_url}}/paquetes/999999/
```

**Expected:** Status 404 con mensaje de error apropiado

### 400 - Filtros Inválidos

```
GET {{base_url}}/paquetes/?precio_min=abc&precio_max=xyz
```

**Expected:** El sistema debe manejar gracefully filtros inválidos

## 📝 Notas para Desarrollo

1. **Base de Datos:** Asegurar que existen paquetes de prueba con diferentes estados y configuraciones
2. **Fechas:** Verificar que las fechas de vigencia estén configuradas correctamente
3. **Servicios:** Cada paquete debe tener al menos un servicio asociado
4. **Imágenes:** URLs de imágenes deben ser válidas (aunque sean placeholders)
5. **Precios:** Verificar conversión BOB está actualizada

## 🔗 Referencias

- **Documentación Completa:** `04_paquetes_turisticos_completos.md`
- **Modelos Django:** `condominio/models.py` - Paquete, PaqueteServicio
- **Serializers:** `condominio/serializer.py` - PaqueteSerializer
- **ViewSet:** `condominio/api.py` - PaqueteViewSet
