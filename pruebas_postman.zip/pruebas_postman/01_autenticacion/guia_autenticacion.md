# 🔐 Autenticación - Pruebas Postman

## 📋 Endpoints Disponibles

### 1. **Registro de Usuario**
```http
POST /auth/register/
Content-Type: application/json

{
    "username": "nuevo_usuario",
    "password": "password123",
    "email": "usuario@example.com",
    "first_name": "Juan",
    "last_name": "Pérez"
}
```

**Respuesta Esperada:**
```json
{
    "user": {
        "id": 1,
        "username": "nuevo_usuario",
        "email": "usuario@example.com"
    },
    "message": "Usuario creado exitosamente"
}
```

### 2. **Login (Obtener Token)**
```http
POST /auth/login/
Content-Type: application/json

{
    "username": "admin",
    "password": "admin123"
}
```

**Respuesta Esperada:**
```json
{
    "access": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
    "refresh": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
    "user": {
        "id": 1,
        "nombre": "Administrador",
        "rol": "Administrador"
    }
}
```

### 3. **Perfil del Usuario Autenticado**
```http
GET /usuarios/me/
Authorization: Bearer {access_token}
```

### 4. **Renovar Token**
```http
POST /auth/token/refresh/
Content-Type: application/json

{
    "refresh": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9..."
}
```

## 👤 Usuarios de Prueba Disponibles

| Usuario | Password | Rol | Descripción |
|---------|----------|-----|-------------|
| `admin` | `admin123` | Administrador | Acceso completo |
| `cliente1` | `cliente123` | Cliente | Usuario regular |
| `soporte1` | `soporte123` | Soporte | Agente de tickets |

## ⚙️ Configuración de Environment

**Variables necesarias:**
- `base_url`: `http://127.0.0.1:8000/api`
- `access_token`: (se obtiene del login)
- `refresh_token`: (se obtiene del login)

## 🔄 Flujo Recomendado

1. **POST** `/auth/login/` → Obtener tokens
2. **Configurar** `access_token` en environment  
3. **GET** `/usuarios/me/` → Verificar autenticación
4. **Usar** token en todas las siguientes requests

---
*Nota: Los tokens JWT tienen expiración, usa refresh cuando sea necesario.*