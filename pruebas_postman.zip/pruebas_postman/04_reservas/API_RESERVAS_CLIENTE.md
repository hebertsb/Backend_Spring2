# 📋 API Reservas para Clientes - Guía Completa

## 🎯 **APIs para que los Clientes Vean sus Reservas**

Esta guía está específicamente diseñada para que el frontend pueda mostrar las reservas de los clientes de manera completa y organizada.

---

## 🔗 **Endpoints Principales**

### **1. Todas mis Reservas** ⭐ (Recomendado)

```
GET /api/reservas/mis_reservas/
```

**Descripción:** Endpoint especializado que devuelve solo las reservas del usuario autenticado con estadísticas completas.

**Headers requeridos:**

```json
{
  "Authorization": "Bearer YOUR_JWT_TOKEN"
}
```

**Parámetros opcionales (Query Parameters):**

- `estado` - Filtrar por estado (PENDIENTE, CONFIRMADA, PAGADA, CANCELADA, etc.)
- `fecha_desde` - Filtrar desde una fecha (formato: YYYY-MM-DD)
- `fecha_hasta` - Filtrar hasta una fecha (formato: YYYY-MM-DD)

**Ejemplo de uso:**

```
GET /api/reservas/mis_reservas/?estado=PAGADA&fecha_desde=2024-01-01
```

**Respuesta exitosa (200):**

```json
{
  "estadisticas": {
    "total_reservas": 8,
    "por_estado": {
      "PENDIENTE": 1,
      "CONFIRMADA": 2,
      "PAGADA": 3,
      "CANCELADA": 1,
      "COMPLETADA": 1,
      "REPROGRAMADA": 0
    }
  },
  "reservas": [
    {
      "id": 15,
      "fecha": "2024-12-20",
      "fecha_inicio": "2024-12-20T08:00:00Z",
      "fecha_fin": "2024-12-20T18:00:00Z",
      "estado": "PAGADA",
      "total": "450.00",
      "moneda": "BOB",
      "cliente": {
        "id": 1,
        "nombre": "Juan Pérez",
        "rubro": "Turismo",
        "telefono": "+591 70123456",
        "rol": {
          "nombre": "Cliente",
          "slug": "cliente"
        }
      },
      "cupon": {
        "id": 3,
        "nro_usos": 1,
        "cantidad_max": 10,
        "campania": {
          "descripcion": "Promo Navidad",
          "monto": "50.00",
          "tipo_descuento": "%"
        }
      },
      "numero_reprogramaciones": 0,
      "motivo_reprogramacion": null,
      "reprogramado_por_nombre": null,
      "created_at": "2024-10-12T10:30:00Z",
      "updated_at": "2024-10-12T11:15:00Z"
    }
  ]
}
```

---

### **2. Reservas Activas**

```
GET /api/reservas/reservas_activas/
```

**Descripción:** Solo las reservas que están activas (no canceladas ni completadas).

**Respuesta exitosa (200):**

```json
{
  "count": 3,
  "reservas_activas": [
    {
      "id": 15,
      "fecha": "2024-12-20",
      "estado": "CONFIRMADA",
      "total": "450.00",
      "moneda": "BOB",
      "cliente": { "id": 1, "nombre": "Juan Pérez" },
      "cupon": null
    }
  ]
}
```

---

### **3. Historial Completo con Reprogramaciones**

```
GET /api/reservas/historial_completo/
```

**Descripción:** Historial completo incluyendo todas las reprogramaciones realizadas.

**Respuesta exitosa (200):**

```json
{
  "count": 5,
  "historial": [
    {
      "id": 12,
      "fecha": "2024-11-15",
      "estado": "REPROGRAMADA",
      "total": "300.00",
      "numero_reprogramaciones": 2,
      "historial_reprogramaciones": [
        {
          "fecha_anterior": "2024-11-10T10:00:00Z",
          "fecha_nueva": "2024-11-12T14:00:00Z",
          "motivo": "Cambio solicitado por cliente",
          "reprogramado_por": "María García",
          "fecha_cambio": "2024-11-08T09:30:00Z"
        },
        {
          "fecha_anterior": "2024-11-12T14:00:00Z",
          "fecha_nueva": "2024-11-15T16:00:00Z",
          "motivo": "Lluvia - reagendar por clima",
          "reprogramado_por": "Carlos López",
          "fecha_cambio": "2024-11-11T11:45:00Z"
        }
      ]
    }
  ]
}
```

---

### **4. Lista General de Reservas (Filtrada automáticamente)**

```
GET /api/reservas/
```

**Descripción:** Endpoint estándar que automáticamente filtra las reservas del usuario autenticado.

**Filtros disponibles:**

- `estado` - Por estado de reserva
- `moneda` - Por tipo de moneda (BOB, USD)
- `search` - Buscar por nombre del cliente o estado

**Ejemplo:**

```
GET /api/reservas/?estado=PAGADA&search=Juan
```

---

### **5. Detalle de Reserva Específica**

```
GET /api/reservas/{id}/
```

**Descripción:** Ver todos los detalles de una reserva específica.

**Respuesta incluye:**

- Datos completos de la reserva
- Información del cliente
- Detalles del cupón usado (si aplica)
- Historial de reprogramaciones
- Visitantes asociados (si los hay)

---

## 🚀 **Implementación Frontend**

### **React/Next.js - Componente Mis Reservas**

```javascript
// Servicio para API de Reservas
const ReservasService = {
  // Obtener todas mis reservas con filtros
  async getMisReservas(filtros = {}) {
    const params = new URLSearchParams(filtros);
    const response = await fetch(`/api/reservas/mis_reservas/?${params}`, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
        "Content-Type": "application/json",
      },
    });

    if (!response.ok) {
      throw new Error("Error al obtener reservas");
    }

    return response.json();
  },

  // Obtener solo reservas activas
  async getReservasActivas() {
    const response = await fetch("/api/reservas/reservas_activas/", {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
        "Content-Type": "application/json",
      },
    });

    return response.json();
  },

  // Obtener historial completo
  async getHistorialCompleto() {
    const response = await fetch("/api/reservas/historial_completo/", {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
        "Content-Type": "application/json",
      },
    });

    return response.json();
  },

  // Obtener detalle de reserva específica
  async getDetalleReserva(id) {
    const response = await fetch(`/api/reservas/${id}/`, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
        "Content-Type": "application/json",
      },
    });

    return response.json();
  },
};

// Componente principal de Mis Reservas
function MisReservas() {
  const [reservas, setReservas] = useState([]);
  const [estadisticas, setEstadisticas] = useState(null);
  const [filtros, setFiltros] = useState({});
  const [loading, setLoading] = useState(true);

  // Cargar reservas con filtros
  const cargarReservas = async (nuevosFiltros = {}) => {
    try {
      setLoading(true);
      const data = await ReservasService.getMisReservas(nuevosFiltros);
      setReservas(data.reservas);
      setEstadisticas(data.estadisticas);
      setFiltros(nuevosFiltros);
    } catch (error) {
      console.error("Error:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    cargarReservas();
  }, []);

  // Función para aplicar filtros
  const aplicarFiltros = (nuevosFiltros) => {
    cargarReservas(nuevosFiltros);
  };

  if (loading) return <div>Cargando reservas...</div>;

  return (
    <div className="mis-reservas">
      {/* Header con estadísticas */}
      <div className="reservas-header">
        <h1>Mis Reservas</h1>
        {estadisticas && (
          <div className="estadisticas-resumen">
            <div className="stat-card">
              <h3>{estadisticas.total_reservas}</h3>
              <p>Total Reservas</p>
            </div>
            <div className="stat-card active">
              <h3>
                {estadisticas.por_estado.CONFIRMADA +
                  estadisticas.por_estado.PAGADA}
              </h3>
              <p>Reservas Activas</p>
            </div>
            <div className="stat-card completed">
              <h3>{estadisticas.por_estado.COMPLETADA}</h3>
              <p>Completadas</p>
            </div>
          </div>
        )}
      </div>

      {/* Filtros */}
      <div className="filtros-reservas">
        <select
          onChange={(e) =>
            aplicarFiltros({ ...filtros, estado: e.target.value })
          }
          value={filtros.estado || ""}
        >
          <option value="">Todos los estados</option>
          <option value="PENDIENTE">Pendiente</option>
          <option value="CONFIRMADA">Confirmada</option>
          <option value="PAGADA">Pagada</option>
          <option value="CANCELADA">Cancelada</option>
          <option value="COMPLETADA">Completada</option>
        </select>

        <input
          type="date"
          placeholder="Desde"
          onChange={(e) =>
            aplicarFiltros({ ...filtros, fecha_desde: e.target.value })
          }
        />

        <input
          type="date"
          placeholder="Hasta"
          onChange={(e) =>
            aplicarFiltros({ ...filtros, fecha_hasta: e.target.value })
          }
        />

        <button onClick={() => aplicarFiltros({})}>Limpiar filtros</button>
      </div>

      {/* Lista de reservas */}
      <div className="lista-reservas">
        {reservas.map((reserva) => (
          <div
            key={reserva.id}
            className={`reserva-card ${reserva.estado.toLowerCase()}`}
          >
            <div className="reserva-header">
              <h3>Reserva #{reserva.id}</h3>
              <span className={`estado ${reserva.estado.toLowerCase()}`}>
                {reserva.estado}
              </span>
            </div>

            <div className="reserva-info">
              <p>
                <strong>Fecha:</strong>{" "}
                {new Date(reserva.fecha).toLocaleDateString()}
              </p>
              <p>
                <strong>Total:</strong> {reserva.total} {reserva.moneda}
              </p>
              {reserva.cupon && (
                <p>
                  <strong>Descuento aplicado:</strong>{" "}
                  {reserva.cupon.campania.descripcion}
                </p>
              )}
              {reserva.numero_reprogramaciones > 0 && (
                <p>
                  <strong>Reprogramaciones:</strong>{" "}
                  {reserva.numero_reprogramaciones}
                </p>
              )}
            </div>

            <div className="reserva-actions">
              <button onClick={() => verDetalle(reserva.id)}>
                Ver Detalle
              </button>
              {reserva.estado === "CONFIRMADA" && (
                <button onClick={() => cancelarReserva(reserva.id)}>
                  Cancelar
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Mensaje si no hay reservas */}
      {reservas.length === 0 && (
        <div className="sin-reservas">
          <p>No tienes reservas que coincidan con los filtros seleccionados.</p>
        </div>
      )}
    </div>
  );
}

// Componente para ver detalle de reserva
function DetalleReserva({ reservaId, onCerrar }) {
  const [reserva, setReserva] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const cargarDetalle = async () => {
      try {
        const data = await ReservasService.getDetalleReserva(reservaId);
        setReserva(data);
      } catch (error) {
        console.error("Error:", error);
      } finally {
        setLoading(false);
      }
    };

    cargarDetalle();
  }, [reservaId]);

  if (loading) return <div>Cargando detalle...</div>;

  return (
    <div className="detalle-reserva">
      <div className="detalle-header">
        <h2>Reserva #{reserva.id}</h2>
        <button onClick={onCerrar}>Cerrar</button>
      </div>

      <div className="detalle-info">
        <div className="info-section">
          <h3>Información General</h3>
          <p>
            <strong>Estado:</strong> {reserva.estado}
          </p>
          <p>
            <strong>Fecha:</strong>{" "}
            {new Date(reserva.fecha).toLocaleDateString()}
          </p>
          <p>
            <strong>Total:</strong> {reserva.total} {reserva.moneda}
          </p>
        </div>

        {reserva.cupon && (
          <div className="info-section">
            <h3>Descuento Aplicado</h3>
            <p>
              <strong>Campaña:</strong> {reserva.cupon.campania.descripcion}
            </p>
            <p>
              <strong>Descuento:</strong> {reserva.cupon.campania.monto}
              {reserva.cupon.campania.tipo_descuento}
            </p>
          </div>
        )}

        {reserva.numero_reprogramaciones > 0 && (
          <div className="info-section">
            <h3>Historial de Reprogramaciones</h3>
            <p>
              <strong>Total reprogramaciones:</strong>{" "}
              {reserva.numero_reprogramaciones}
            </p>
            {reserva.motivo_reprogramacion && (
              <p>
                <strong>Último motivo:</strong> {reserva.motivo_reprogramacion}
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
```

### **Vue.js - Componente Reservas**

```vue
<template>
  <div class="mis-reservas" v-if="!loading">
    <!-- Header con estadísticas -->
    <div class="reservas-header">
      <h1>Mis Reservas</h1>
      <div class="estadisticas-resumen" v-if="estadisticas">
        <div class="stat-card">
          <h3>{{ estadisticas.total_reservas }}</h3>
          <p>Total Reservas</p>
        </div>
        <div class="stat-card active">
          <h3>
            {{
              estadisticas.por_estado.CONFIRMADA +
              estadisticas.por_estado.PAGADA
            }}
          </h3>
          <p>Activas</p>
        </div>
        <div class="stat-card completed">
          <h3>{{ estadisticas.por_estado.COMPLETADA }}</h3>
          <p>Completadas</p>
        </div>
      </div>
    </div>

    <!-- Filtros -->
    <div class="filtros-reservas">
      <select v-model="filtros.estado" @change="aplicarFiltros">
        <option value="">Todos los estados</option>
        <option value="PENDIENTE">Pendiente</option>
        <option value="CONFIRMADA">Confirmada</option>
        <option value="PAGADA">Pagada</option>
        <option value="CANCELADA">Cancelada</option>
        <option value="COMPLETADA">Completada</option>
      </select>

      <input
        type="date"
        v-model="filtros.fecha_desde"
        @change="aplicarFiltros"
        placeholder="Desde"
      />

      <input
        type="date"
        v-model="filtros.fecha_hasta"
        @change="aplicarFiltros"
        placeholder="Hasta"
      />

      <button @click="limpiarFiltros">Limpiar</button>
    </div>

    <!-- Lista de reservas -->
    <div class="lista-reservas">
      <div
        v-for="reserva in reservas"
        :key="reserva.id"
        :class="`reserva-card ${reserva.estado.toLowerCase()}`"
      >
        <div class="reserva-header">
          <h3>Reserva #{{ reserva.id }}</h3>
          <span :class="`estado ${reserva.estado.toLowerCase()}`">
            {{ reserva.estado }}
          </span>
        </div>

        <div class="reserva-info">
          <p><strong>Fecha:</strong> {{ formatearFecha(reserva.fecha) }}</p>
          <p>
            <strong>Total:</strong> {{ reserva.total }} {{ reserva.moneda }}
          </p>
          <p v-if="reserva.cupon">
            <strong>Descuento:</strong> {{ reserva.cupon.campania.descripcion }}
          </p>
          <p v-if="reserva.numero_reprogramaciones > 0">
            <strong>Reprogramaciones:</strong>
            {{ reserva.numero_reprogramaciones }}
          </p>
        </div>

        <div class="reserva-actions">
          <button @click="verDetalle(reserva.id)">Ver Detalle</button>
          <button
            v-if="reserva.estado === 'CONFIRMADA'"
            @click="cancelarReserva(reserva.id)"
          >
            Cancelar
          </button>
        </div>
      </div>
    </div>

    <!-- Sin reservas -->
    <div v-if="reservas.length === 0" class="sin-reservas">
      <p>No tienes reservas que coincidan con los filtros seleccionados.</p>
    </div>
  </div>
</template>

<script>
import { ref, onMounted, reactive } from "vue";
import axios from "axios";

export default {
  name: "MisReservas",
  setup() {
    const reservas = ref([]);
    const estadisticas = ref(null);
    const loading = ref(true);
    const filtros = reactive({
      estado: "",
      fecha_desde: "",
      fecha_hasta: "",
    });

    const getHeaders = () => ({
      Authorization: `Bearer ${localStorage.getItem("token")}`,
      "Content-Type": "application/json",
    });

    const cargarReservas = async () => {
      try {
        loading.value = true;
        const params = new URLSearchParams();

        Object.keys(filtros).forEach((key) => {
          if (filtros[key]) {
            params.append(key, filtros[key]);
          }
        });

        const response = await axios.get(
          `/api/reservas/mis_reservas/?${params}`,
          {
            headers: getHeaders(),
          }
        );

        reservas.value = response.data.reservas;
        estadisticas.value = response.data.estadisticas;
      } catch (error) {
        console.error("Error:", error);
      } finally {
        loading.value = false;
      }
    };

    const aplicarFiltros = () => {
      cargarReservas();
    };

    const limpiarFiltros = () => {
      filtros.estado = "";
      filtros.fecha_desde = "";
      filtros.fecha_hasta = "";
      cargarReservas();
    };

    const formatearFecha = (fecha) => {
      return new Date(fecha).toLocaleDateString();
    };

    const verDetalle = (id) => {
      // Implementar navegación al detalle
      console.log("Ver detalle de reserva:", id);
    };

    const cancelarReserva = async (id) => {
      if (confirm("¿Estás seguro de cancelar esta reserva?")) {
        try {
          await axios.patch(
            `/api/reservas/${id}/`,
            {
              estado: "CANCELADA",
            },
            {
              headers: getHeaders(),
            }
          );

          cargarReservas(); // Recargar lista
        } catch (error) {
          console.error("Error al cancelar:", error);
        }
      }
    };

    onMounted(() => {
      cargarReservas();
    });

    return {
      reservas,
      estadisticas,
      loading,
      filtros,
      aplicarFiltros,
      limpiarFiltros,
      formatearFecha,
      verDetalle,
      cancelarReserva,
    };
  },
};
</script>
```

### **Angular - Servicio y Componente**

```typescript
// reservas.service.ts
import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { Observable } from "rxjs";

export interface Reserva {
  id: number;
  fecha: string;
  estado: string;
  total: number;
  moneda: string;
  cliente: any;
  cupon: any;
  numero_reprogramaciones: number;
}

export interface ReservasResponse {
  estadisticas: any;
  reservas: Reserva[];
}

@Injectable({
  providedIn: "root",
})
export class ReservasService {
  private baseUrl = "/api/reservas";

  constructor(private http: HttpClient) {}

  private getHeaders(): HttpHeaders {
    const token = localStorage.getItem("token");
    return new HttpHeaders({
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    });
  }

  getMisReservas(filtros: any = {}): Observable<ReservasResponse> {
    let params = new HttpParams();
    Object.keys(filtros).forEach((key) => {
      if (filtros[key]) {
        params = params.set(key, filtros[key]);
      }
    });

    return this.http.get<ReservasResponse>(`${this.baseUrl}/mis_reservas/`, {
      headers: this.getHeaders(),
      params: params,
    });
  }

  getReservasActivas(): Observable<any> {
    return this.http.get(`${this.baseUrl}/reservas_activas/`, {
      headers: this.getHeaders(),
    });
  }

  getDetalleReserva(id: number): Observable<Reserva> {
    return this.http.get<Reserva>(`${this.baseUrl}/${id}/`, {
      headers: this.getHeaders(),
    });
  }

  cancelarReserva(id: number): Observable<any> {
    return this.http.patch(
      `${this.baseUrl}/${id}/`,
      { estado: "CANCELADA" },
      { headers: this.getHeaders() }
    );
  }
}

// mis-reservas.component.ts
import { Component, OnInit } from "@angular/core";
import { ReservasService, Reserva, ReservasResponse } from "./reservas.service";

@Component({
  selector: "app-mis-reservas",
  template: `
    <div class="mis-reservas" *ngIf="!loading">
      <!-- Header -->
      <div class="reservas-header">
        <h1>Mis Reservas</h1>
        <div class="estadisticas-resumen" *ngIf="estadisticas">
          <div class="stat-card">
            <h3>{{ estadisticas.total_reservas }}</h3>
            <p>Total Reservas</p>
          </div>
          <div class="stat-card active">
            <h3>
              {{
                estadisticas.por_estado.CONFIRMADA +
                  estadisticas.por_estado.PAGADA
              }}
            </h3>
            <p>Activas</p>
          </div>
          <div class="stat-card completed">
            <h3>{{ estadisticas.por_estado.COMPLETADA }}</h3>
            <p>Completadas</p>
          </div>
        </div>
      </div>

      <!-- Filtros -->
      <div class="filtros-reservas">
        <select [(ngModel)]="filtros.estado" (change)="aplicarFiltros()">
          <option value="">Todos los estados</option>
          <option value="PENDIENTE">Pendiente</option>
          <option value="CONFIRMADA">Confirmada</option>
          <option value="PAGADA">Pagada</option>
          <option value="CANCELADA">Cancelada</option>
          <option value="COMPLETADA">Completada</option>
        </select>

        <input
          type="date"
          [(ngModel)]="filtros.fecha_desde"
          (change)="aplicarFiltros()"
        />

        <input
          type="date"
          [(ngModel)]="filtros.fecha_hasta"
          (change)="aplicarFiltros()"
        />

        <button (click)="limpiarFiltros()">Limpiar</button>
      </div>

      <!-- Lista reservas -->
      <div class="lista-reservas">
        <div
          *ngFor="let reserva of reservas"
          [ngClass]="'reserva-card ' + reserva.estado.toLowerCase()"
        >
          <div class="reserva-header">
            <h3>Reserva #{{ reserva.id }}</h3>
            <span [ngClass]="'estado ' + reserva.estado.toLowerCase()">
              {{ reserva.estado }}
            </span>
          </div>

          <div class="reserva-info">
            <p><strong>Fecha:</strong> {{ reserva.fecha | date }}</p>
            <p>
              <strong>Total:</strong> {{ reserva.total }} {{ reserva.moneda }}
            </p>
            <p *ngIf="reserva.cupon">
              <strong>Descuento:</strong>
              {{ reserva.cupon.campania.descripcion }}
            </p>
            <p *ngIf="reserva.numero_reprogramaciones > 0">
              <strong>Reprogramaciones:</strong>
              {{ reserva.numero_reprogramaciones }}
            </p>
          </div>

          <div class="reserva-actions">
            <button (click)="verDetalle(reserva.id)">Ver Detalle</button>
            <button
              *ngIf="reserva.estado === 'CONFIRMADA'"
              (click)="cancelarReserva(reserva.id)"
            >
              Cancelar
            </button>
          </div>
        </div>
      </div>

      <!-- Sin reservas -->
      <div *ngIf="reservas.length === 0" class="sin-reservas">
        <p>No tienes reservas que coincidan con los filtros seleccionados.</p>
      </div>
    </div>
  `,
})
export class MisReservasComponent implements OnInit {
  reservas: Reserva[] = [];
  estadisticas: any = null;
  loading = true;
  filtros = {
    estado: "",
    fecha_desde: "",
    fecha_hasta: "",
  };

  constructor(private reservasService: ReservasService) {}

  ngOnInit() {
    this.cargarReservas();
  }

  cargarReservas() {
    this.loading = true;
    this.reservasService.getMisReservas(this.filtros).subscribe({
      next: (data: ReservasResponse) => {
        this.reservas = data.reservas;
        this.estadisticas = data.estadisticas;
        this.loading = false;
      },
      error: (error) => {
        console.error("Error:", error);
        this.loading = false;
      },
    });
  }

  aplicarFiltros() {
    this.cargarReservas();
  }

  limpiarFiltros() {
    this.filtros = {
      estado: "",
      fecha_desde: "",
      fecha_hasta: "",
    };
    this.cargarReservas();
  }

  verDetalle(id: number) {
    // Implementar navegación
    console.log("Ver detalle:", id);
  }

  cancelarReserva(id: number) {
    if (confirm("¿Estás seguro de cancelar esta reserva?")) {
      this.reservasService.cancelarReserva(id).subscribe({
        next: () => {
          this.cargarReservas(); // Recargar
        },
        error: (error) => {
          console.error("Error al cancelar:", error);
        },
      });
    }
  }
}
```

---

## 📱 **Estados de Reservas**

### **Estados Disponibles:**

- **PENDIENTE** - Reserva creada, esperando confirmación
- **CONFIRMADA** - Reserva confirmada por el sistema
- **PAGADA** - Pago procesado correctamente
- **CANCELADA** - Reserva cancelada por cliente o sistema
- **COMPLETADA** - Servicio completado exitosamente
- **REPROGRAMADA** - Reserva reprogramada una o más veces

### **Colores Sugeridos:**

```css
.estado.pendiente {
  background: #fff3cd;
  color: #856404;
}
.estado.confirmada {
  background: #d1ecf1;
  color: #0c5460;
}
.estado.pagada {
  background: #d4edda;
  color: #155724;
}
.estado.cancelada {
  background: #f8d7da;
  color: #721c24;
}
.estado.completada {
  background: #e2e3e5;
  color: #383d41;
}
.estado.reprogramada {
  background: #e7f3ff;
  color: #004085;
}
```

---

## 🔄 **Flujo de Uso Recomendado**

### **1. Dashboard del Cliente**

```javascript
// Cargar resumen de reservas activas para el dashboard
const reservasActivas = await fetch("/api/reservas/reservas_activas/", {
  headers: { Authorization: `Bearer ${token}` },
});
// Mostrar: cantidad de reservas activas, próximas fechas
```

### **2. Página "Mis Reservas"**

```javascript
// Cargar reservas completas con estadísticas
const misReservas = await fetch("/api/reservas/mis_reservas/", {
  headers: { Authorization: `Bearer ${token}` },
});
// Mostrar: lista completa, filtros, estadísticas
```

### **3. Detalle de Reserva**

```javascript
// Ver detalle específico de una reserva
const detalle = await fetch(`/api/reservas/${id}/`, {
  headers: { Authorization: `Bearer ${token}` },
});
// Mostrar: todos los detalles, opciones de cancelar/modificar
```

---

## ⚠️ **Consideraciones Importantes**

### **Autenticación Automática**

- Las APIs filtran automáticamente por usuario autenticado
- Los clientes solo ven sus propias reservas
- Los administradores pueden ver todas las reservas

### **Permisos por Rol**

- **Cliente:** Solo sus reservas
- **Admin/Soporte:** Todas las reservas del sistema

### **Rendimiento**

- Queries optimizadas con `select_related` y `prefetch_related`
- Paginación automática en listas grandes
- Filtros eficientes por base de datos

---

## 🎯 **URLs Rápidas de Referencia**

```
GET /api/reservas/mis_reservas/              # ⭐ Principal - Todas mis reservas
GET /api/reservas/reservas_activas/          # Solo reservas activas
GET /api/reservas/historial_completo/        # Con reprogramaciones
GET /api/reservas/                           # Lista general (filtrada)
GET /api/reservas/{id}/                      # Detalle específico
PATCH /api/reservas/{id}/                    # Actualizar (ej: cancelar)
```

**Esta guía proporciona todo lo necesario para implementar un sistema completo de visualización de reservas para clientes en el frontend.**
