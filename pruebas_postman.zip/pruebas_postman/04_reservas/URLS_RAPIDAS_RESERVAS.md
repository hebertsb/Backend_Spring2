# 🚀 URLs RÁPIDAS - Reservas de Cliente

## 📋 **APIs Principales para Frontend**

### **🎯 ENDPOINTS MÁS IMPORTANTES**

#### **1. Todas mis Reservas (RECOMENDADO)**

```
GET /api/reservas/mis_reservas/
```

- ✅ **Incluye estadísticas completas**
- ✅ **Filtros: estado, fecha_desde, fecha_hasta**
- ✅ **Datos completos del cliente y cupones**

#### **2. Solo Reservas Activas**

```
GET /api/reservas/reservas_activas/
```

- ✅ **Para dashboard o widgets**
- ✅ **Excluye canceladas y completadas**

#### **3. Detalle de Reserva Específica**

```
GET /api/reservas/{id}/
```

- ✅ **Información completa de una reserva**
- ✅ **Para páginas de detalle**

---

## 🔗 **Ejemplos de Uso Rápido**

### **JavaScript Vanilla**

```javascript
// Mis reservas con filtros
const response = await fetch("/api/reservas/mis_reservas/?estado=PAGADA", {
  headers: { Authorization: `Bearer ${token}` },
});
const data = await response.json();
console.log(data.estadisticas); // Estadísticas
console.log(data.reservas); // Array de reservas
```

### **React Hook**

```javascript
const useMisReservas = () => {
  const [data, setData] = useState(null);

  useEffect(() => {
    fetch("/api/reservas/mis_reservas/", {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((res) => res.json())
      .then(setData);
  }, []);

  return data;
};
```

### **Vue Composable**

```javascript
const useMisReservas = () => {
  const reservas = ref([]);
  const estadisticas = ref(null);

  const cargar = async () => {
    const res = await fetch("/api/reservas/mis_reservas/", {
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    reservas.value = data.reservas;
    estadisticas.value = data.estadisticas;
  };

  return { reservas, estadisticas, cargar };
};
```

---

## 📊 **Respuesta Típica**

```json
{
  "estadisticas": {
    "total_reservas": 8,
    "por_estado": {
      "PENDIENTE": 1,
      "CONFIRMADA": 2,
      "PAGADA": 3,
      "CANCELADA": 1,
      "COMPLETADA": 1,
      "REPROGRAMADA": 0
    }
  },
  "reservas": [
    {
      "id": 15,
      "fecha": "2024-12-20",
      "estado": "PAGADA",
      "total": "450.00",
      "moneda": "BOB",
      "cliente": { "nombre": "Juan Pérez" },
      "cupon": null,
      "numero_reprogramaciones": 0
    }
  ]
}
```

---

## 🎨 **Filtros Disponibles**

### **Por Estado**

```
?estado=PAGADA
?estado=CONFIRMADA
?estado=PENDIENTE
```

### **Por Fecha**

```
?fecha_desde=2024-01-01
?fecha_hasta=2024-12-31
?fecha_desde=2024-01-01&fecha_hasta=2024-06-30
```

### **Combinados**

```
?estado=PAGADA&fecha_desde=2024-01-01&fecha_hasta=2024-12-31
```

---

## ⚡ **Para Implementación Rápida**

### **1. Dashboard - Reservas Activas**

```
GET /api/reservas/reservas_activas/
→ Mostrar cantidad y próximas fechas
```

### **2. Página Completa - Todas las Reservas**

```
GET /api/reservas/mis_reservas/
→ Lista completa con filtros y estadísticas
```

### **3. Modal/Detalle - Reserva Específica**

```
GET /api/reservas/{id}/
→ Información completa para modal o página detalle
```

---

## 🔧 **Headers Requeridos**

```javascript
const headers = {
  Authorization: `Bearer ${localStorage.getItem("token")}`,
  "Content-Type": "application/json",
};
```

---

**✨ Con estas 3 APIs principales puedes implementar un sistema completo de reservas para clientes.**
