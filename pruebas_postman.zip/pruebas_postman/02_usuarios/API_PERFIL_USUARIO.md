# 👤 API Perfil de Usuario - Guía Completa

## 📋 Resumen

API especializada para mostrar perfiles completos de usuarios con estadísticas personalizadas. Permite al frontend acceder a información detallada del usuario autenticado incluyendo reservas, datos personales y estadísticas de uso.

---

## 🔗 Endpoints Disponibles

### 1. **Mi Perfil Completo**

```
GET /api/perfil/mi_perfil/
```

**Headers requeridos:**

```json
{
  "Authorization": "Bearer YOUR_JWT_TOKEN"
}
```

**Respuesta exitosa (200):**

```json
{
  "id": 1,
  "nombre": "Juan Pérez",
  "rubro": "Turismo",
  "num_viajes": 5,
  "rol": {
    "id": 2,
    "nombre": "Cliente",
    "descripcion": "Usuario cliente del sistema",
    "slug": "cliente"
  },
  "telefono": "+591 70123456",
  "fecha_nacimiento": "1990-05-15",
  "genero": "M",
  "documento_identidad": "12345678",
  "pais": "Bolivia",
  "email": "juan.perez@email.com",
  "username": "juanperez",
  "fecha_registro": "2024-01-15T10:30:00Z",
  "ultimo_acceso": "2024-10-12T09:15:00Z",
  "total_reservas": 8,
  "reservas_activas": 2,
  "total_gastado": 1250.5,
  "created_at": "2024-01-15T10:30:00Z",
  "updated_at": "2024-10-12T08:45:00Z"
}
```

---

### 2. **Mis Reservas**

```
GET /api/perfil/mis_reservas/
```

**Headers requeridos:**

```json
{
  "Authorization": "Bearer YOUR_JWT_TOKEN"
}
```

**Respuesta exitosa (200):**

```json
{
  "count": 8,
  "reservas": [
    {
      "id": 15,
      "fecha": "2024-12-20",
      "estado": "CONFIRMADA",
      "total": 450.0,
      "moneda": "BOB",
      "fecha_creacion": "2024-10-12T10:30:00Z",
      "cupon_usado": 3
    },
    {
      "id": 14,
      "fecha": "2024-11-15",
      "estado": "PAGADA",
      "total": 800.5,
      "moneda": "BOB",
      "fecha_creacion": "2024-10-01T14:20:00Z",
      "cupon_usado": null
    }
  ]
}
```

---

### 3. **Lista de Perfiles** (Solo lectura)

```
GET /api/perfil/
```

**Nota:** Solo devuelve el perfil del usuario autenticado

**Headers requeridos:**

```json
{
  "Authorization": "Bearer YOUR_JWT_TOKEN"
}
```

---

## 🚀 Implementación Frontend

### **React/Next.js**

```javascript
// Servicio para perfil de usuario
const PerfilService = {
  // Obtener perfil completo
  async getMiPerfil() {
    const response = await fetch("/api/perfil/mi_perfil/", {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
        "Content-Type": "application/json",
      },
    });

    if (!response.ok) {
      throw new Error("Error al obtener perfil");
    }

    return response.json();
  },

  // Obtener mis reservas
  async getMisReservas() {
    const response = await fetch("/api/perfil/mis_reservas/", {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
        "Content-Type": "application/json",
      },
    });

    return response.json();
  },
};

// Componente Perfil Usuario
function PerfilUsuario() {
  const [perfil, setPerfil] = useState(null);
  const [reservas, setReservas] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const cargarDatos = async () => {
      try {
        const [perfilData, reservasData] = await Promise.all([
          PerfilService.getMiPerfil(),
          PerfilService.getMisReservas(),
        ]);

        setPerfil(perfilData);
        setReservas(reservasData.reservas);
      } catch (error) {
        console.error("Error:", error);
      } finally {
        setLoading(false);
      }
    };

    cargarDatos();
  }, []);

  if (loading) return <div>Cargando...</div>;

  return (
    <div className="perfil-usuario">
      <div className="perfil-header">
        <h1>Mi Perfil</h1>
        <div className="info-basica">
          <h2>{perfil.nombre}</h2>
          <p>Email: {perfil.email}</p>
          <p>Teléfono: {perfil.telefono}</p>
          <p>Rol: {perfil.rol.nombre}</p>
        </div>
      </div>

      <div className="estadisticas">
        <div className="stat-card">
          <h3>{perfil.total_reservas}</h3>
          <p>Total Reservas</p>
        </div>
        <div className="stat-card">
          <h3>{perfil.reservas_activas}</h3>
          <p>Reservas Activas</p>
        </div>
        <div className="stat-card">
          <h3>Bs. {perfil.total_gastado}</h3>
          <p>Total Gastado</p>
        </div>
      </div>

      <div className="reservas-recientes">
        <h3>Mis Reservas</h3>
        {reservas.map((reserva) => (
          <div key={reserva.id} className="reserva-card">
            <p>Fecha: {reserva.fecha}</p>
            <p>
              Estado:{" "}
              <span className={reserva.estado.toLowerCase()}>
                {reserva.estado}
              </span>
            </p>
            <p>
              Total: {reserva.total} {reserva.moneda}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
```

### **Vue.js**

```vue
<template>
  <div class="perfil-usuario" v-if="!loading">
    <div class="perfil-header">
      <h1>Mi Perfil</h1>
      <div class="info-basica">
        <h2>{{ perfil.nombre }}</h2>
        <p>Email: {{ perfil.email }}</p>
        <p>Teléfono: {{ perfil.telefono }}</p>
        <p>Rol: {{ perfil.rol.nombre }}</p>
      </div>
    </div>

    <div class="estadisticas">
      <div class="stat-card">
        <h3>{{ perfil.total_reservas }}</h3>
        <p>Total Reservas</p>
      </div>
      <div class="stat-card">
        <h3>{{ perfil.reservas_activas }}</h3>
        <p>Reservas Activas</p>
      </div>
      <div class="stat-card">
        <h3>Bs. {{ perfil.total_gastado }}</h3>
        <p>Total Gastado</p>
      </div>
    </div>

    <div class="reservas-recientes">
      <h3>Mis Reservas</h3>
      <div v-for="reserva in reservas" :key="reserva.id" class="reserva-card">
        <p>Fecha: {{ reserva.fecha }}</p>
        <p>
          Estado:
          <span :class="reserva.estado.toLowerCase()">{{
            reserva.estado
          }}</span>
        </p>
        <p>Total: {{ reserva.total }} {{ reserva.moneda }}</p>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, onMounted } from "vue";
import axios from "axios";

export default {
  name: "PerfilUsuario",
  setup() {
    const perfil = ref(null);
    const reservas = ref([]);
    const loading = ref(true);

    const cargarPerfil = async () => {
      try {
        const token = localStorage.getItem("token");
        const headers = {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        };

        const [perfilRes, reservasRes] = await Promise.all([
          axios.get("/api/perfil/mi_perfil/", { headers }),
          axios.get("/api/perfil/mis_reservas/", { headers }),
        ]);

        perfil.value = perfilRes.data;
        reservas.value = reservasRes.data.reservas;
      } catch (error) {
        console.error("Error:", error);
      } finally {
        loading.value = false;
      }
    };

    onMounted(() => {
      cargarPerfil();
    });

    return {
      perfil,
      reservas,
      loading,
    };
  },
};
</script>
```

### **Angular**

```typescript
// perfil.service.ts
import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";

export interface Perfil {
  id: number;
  nombre: string;
  email: string;
  telefono: string;
  rol: any;
  total_reservas: number;
  reservas_activas: number;
  total_gastado: number;
  // ... otros campos
}

@Injectable({
  providedIn: "root",
})
export class PerfilService {
  private baseUrl = "/api/perfil";

  constructor(private http: HttpClient) {}

  private getHeaders(): HttpHeaders {
    const token = localStorage.getItem("token");
    return new HttpHeaders({
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    });
  }

  getMiPerfil(): Observable<Perfil> {
    return this.http.get<Perfil>(`${this.baseUrl}/mi_perfil/`, {
      headers: this.getHeaders(),
    });
  }

  getMisReservas(): Observable<any> {
    return this.http.get(`${this.baseUrl}/mis_reservas/`, {
      headers: this.getHeaders(),
    });
  }
}

// perfil.component.ts
import { Component, OnInit } from "@angular/core";
import { PerfilService } from "./perfil.service";

@Component({
  selector: "app-perfil",
  template: `
    <div class="perfil-usuario" *ngIf="!loading">
      <div class="perfil-header">
        <h1>Mi Perfil</h1>
        <div class="info-basica">
          <h2>{{ perfil?.nombre }}</h2>
          <p>Email: {{ perfil?.email }}</p>
          <p>Teléfono: {{ perfil?.telefono }}</p>
          <p>Rol: {{ perfil?.rol?.nombre }}</p>
        </div>
      </div>

      <div class="estadisticas">
        <div class="stat-card">
          <h3>{{ perfil?.total_reservas }}</h3>
          <p>Total Reservas</p>
        </div>
        <div class="stat-card">
          <h3>{{ perfil?.reservas_activas }}</h3>
          <p>Reservas Activas</p>
        </div>
        <div class="stat-card">
          <h3>Bs. {{ perfil?.total_gastado }}</h3>
          <p>Total Gastado</p>
        </div>
      </div>

      <div class="reservas-recientes">
        <h3>Mis Reservas</h3>
        <div *ngFor="let reserva of reservas" class="reserva-card">
          <p>Fecha: {{ reserva.fecha }}</p>
          <p>
            Estado:
            <span [ngClass]="reserva.estado.toLowerCase()">{{
              reserva.estado
            }}</span>
          </p>
          <p>Total: {{ reserva.total }} {{ reserva.moneda }}</p>
        </div>
      </div>
    </div>
  `,
})
export class PerfilComponent implements OnInit {
  perfil: any = null;
  reservas: any[] = [];
  loading = true;

  constructor(private perfilService: PerfilService) {}

  ngOnInit() {
    this.cargarDatos();
  }

  private async cargarDatos() {
    try {
      const [perfilData, reservasData] = await Promise.all([
        this.perfilService.getMiPerfil().toPromise(),
        this.perfilService.getMisReservas().toPromise(),
      ]);

      this.perfil = perfilData;
      this.reservas = reservasData.reservas;
    } catch (error) {
      console.error("Error:", error);
    } finally {
      this.loading = false;
    }
  }
}
```

---

## 📝 Casos de Uso

### **1. Dashboard de Usuario**

- Mostrar estadísticas personales del usuario
- Información de perfil completa
- Historial de reservas

### **2. Página de Perfil**

- Datos personales completos
- Información de contacto
- Estadísticas de uso del sistema

### **3. Panel de Reservas**

- Lista completa de reservas del usuario
- Estados de reservas
- Totales gastados

---

## ⚠️ Consideraciones Importantes

### **Autenticación**

- **Requerida:** Todos los endpoints requieren token JWT válido
- **Scope:** Solo datos del usuario autenticado
- **Seguridad:** No se exponen datos de otros usuarios

### **Permisos**

- Solo lectura (ReadOnly)
- Para editar perfil usar `/api/usuarios/{id}/`
- Acceso limitado al propio perfil

### **Rendimiento**

- Queries optimizadas con `select_related` y `prefetch_related`
- Cálculos de estadísticas en tiempo real
- Datos de reservas limitados a información esencial

---

## 🔄 Flujo Recomendado

1. **Login/Autenticación** → Obtener JWT token
2. **Cargar Perfil** → `/api/perfil/mi_perfil/`
3. **Mostrar Dashboard** → Usar estadísticas del perfil
4. **Cargar Reservas** → `/api/perfil/mis_reservas/` (si necesario)
5. **Editar Perfil** → Redirigir a `/api/usuarios/` endpoint

---

## 🐛 Errores Comunes

### **401 Unauthorized**

```json
{
  "detail": "Las credenciales de autenticación no se proveyeron."
}
```

**Solución:** Verificar que el token JWT esté incluido en headers

### **404 Not Found**

```json
{
  "error": "No se encontró el perfil del usuario"
}
```

**Solución:** Asegurar que el usuario tenga un perfil creado

### **403 Forbidden**

**Solución:** Verificar que el token JWT sea válido y no haya expirado

---

Esta API proporciona toda la información necesaria para implementar perfiles de usuario completos en el frontend, con estadísticas en tiempo real y acceso seguro a los datos personales.
