# 👥 Usuarios - CRUD Completo

## 📋 Endpoints Básicos

### **Listar Usuarios**
```http
GET /usuarios/
Authorization: Bearer {access_token}
```

### **Crear Usuario**
```http
POST /usuarios/
Content-Type: application/json
Authorization: Bearer {access_token}

{
    "user": 1,
    "nombre": "María González", 
    "rubro": "Turismo Aventura",
    "num_viajes": 0,
    "documento_identidad": "87654321",
    "fecha_nacimiento": "1990-05-15",
    "telefono": "+591 70123456"
}
```

### **Ver Usuario Específico**
```http
GET /usuarios/1/
Authorization: Bearer {access_token}
```

### **Actualizar Usuario**
```http
PUT /usuarios/1/
Content-Type: application/json
Authorization: Bearer {access_token}

{
    "nombre": "María González Actualizada",
    "rubro": "Ecoturismo",
    "num_viajes": 3
}
```

### **Eliminar Usuario**
```http
DELETE /usuarios/1/
Authorization: Bearer {access_token}
```

## 👤 Datos de Usuarios Existentes

| ID | Nombre | Rubro | Viajes |
|----|--------|-------|--------|
| 1 | Admin Principal | Administración | 0 |
| 2 | Cliente Ejemplo | Turismo | 2 |
| 3 | Proveedor Local | Servicios | 5 |

---
*Recuerda: Los usuarios están vinculados al sistema de autenticación Django.*