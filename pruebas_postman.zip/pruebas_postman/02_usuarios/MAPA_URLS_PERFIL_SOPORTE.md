# 🗺️ Mapa de URLs - Perfiles y Soporte

## 📋 URLs Principales del Sistema

### 🔐 **Autenticación** (Requerida para todas las APIs)
```
POST /api/auth/login/         # Login y obtener JWT token
POST /api/auth/register/      # Registro de usuario
POST /api/auth/refresh/       # Renovar token
```

---

## 👤 **PERFILES DE USUARIO**

### **Perfil Completo**
```
GET  /api/perfil/                    # Lista perfiles (solo el propio)
GET  /api/perfil/mi_perfil/          # 🎯 Mi perfil completo con estadísticas
GET  /api/perfil/mis_reservas/       # 🎯 Mis reservas detalladas
```

### **Gestión de Usuarios (Edición)**
```
GET   /api/usuarios/                 # Lista usuarios (admin)
POST  /api/usuarios/                 # Crear usuario
GET   /api/usuarios/{id}/            # Detalle usuario específico
PUT   /api/usuarios/{id}/            # 🔧 Editar perfil completo
PATCH /api/usuarios/{id}/            # 🔧 Editar campos específicos
GET   /api/usuarios/me/              # Info básica usuario autenticado
```

---

## 🎫 **SISTEMA DE SOPORTE**

### **Panel de Soporte (Recomendado para Frontend)**
```
GET  /api/soporte-panel/                      # 🎯 Panel general + estadísticas
GET  /api/soporte-panel/mis_tickets/          # 🎯 Lista mis tickets
POST /api/soporte-panel/crear_ticket_rapido/  # 🎯 Crear ticket rápido
GET  /api/soporte-panel/notificaciones_soporte/ # 🎯 Notificaciones de soporte
```

### **Gestión Completa de Tickets**
```
GET   /api/tickets/                   # Lista tickets (del usuario)
POST  /api/tickets/                   # 🔧 Crear ticket completo
GET   /api/tickets/{id}/              # 🔍 Detalle ticket específico
PUT   /api/tickets/{id}/              # Actualizar ticket
POST  /api/tickets/{id}/close/        # 🔧 Cerrar ticket

GET   /api/ticket-messages/           # Lista mensajes de tickets
POST  /api/ticket-messages/           # 🔧 Enviar mensaje a ticket
```

### **Notificaciones**
```
GET   /api/notificaciones/            # Lista notificaciones del usuario
POST  /api/notificaciones/            # Crear notificación
PUT   /api/notificaciones/{id}/       # Marcar como leída
```

---

## 🎯 **RUTAS RECOMENDADAS POR USO**

### **Dashboard del Cliente**
```
1. GET /api/perfil/mi_perfil/         # Cargar perfil y estadísticas
2. GET /api/soporte-panel/            # Estado del soporte
3. GET /api/paquetes/?activo=true     # Paquetes disponibles
```

### **Panel de Perfil**
```
1. GET /api/perfil/mi_perfil/         # Datos completos del usuario
2. GET /api/perfil/mis_reservas/      # Historial de reservas
3. PUT /api/usuarios/{id}/            # Para editar perfil
```

### **Centro de Soporte**
```
1. GET /api/soporte-panel/            # Panel principal
2. GET /api/soporte-panel/mis_tickets/ # Lista tickets
3. POST /api/soporte-panel/crear_ticket_rapido/ # Crear ticket rápido
```

### **Gestión Avanzada de Tickets**
```
1. GET /api/tickets/{id}/             # Ver ticket completo
2. POST /api/ticket-messages/         # Responder en ticket
3. POST /api/tickets/{id}/close/      # Cerrar ticket
```

---

## 🔗 **Flujos de Navegación Frontend**

### **Flujo Principal Usuario**
```
Login → Dashboard → [Perfil | Soporte | Reservas]
  ↓
/api/auth/login/ → /api/perfil/mi_perfil/ → Navegación interna
```

### **Flujo Soporte Cliente**
```
Dashboard → Soporte → [Crear Ticket | Ver Tickets | Notificaciones]
  ↓
/api/soporte-panel/ → /api/soporte-panel/mis_tickets/ → Ticket específico
```

### **Flujo Perfil Usuario**
```
Dashboard → Mi Perfil → [Ver Info | Editar | Ver Reservas]
  ↓
/api/perfil/mi_perfil/ → /api/usuarios/{id}/ (editar) → /api/perfil/mis_reservas/
```

---

## 📱 **Organización por Pantallas Frontend**

### **1. Dashboard Principal** (`/dashboard`)
- **APIs necesarias:**
  - `GET /api/perfil/mi_perfil/` - Info usuario y estadísticas
  - `GET /api/soporte-panel/` - Estado soporte
  - `GET /api/paquetes/?activo=true` - Ofertas disponibles

### **2. Mi Perfil** (`/perfil`)
- **APIs necesarias:**
  - `GET /api/perfil/mi_perfil/` - Datos completos
  - `PUT /api/usuarios/{id}/` - Editar perfil
  - `GET /api/perfil/mis_reservas/` - Historial

### **3. Centro de Soporte** (`/soporte`)
- **APIs necesarias:**
  - `GET /api/soporte-panel/` - Panel principal
  - `GET /api/soporte-panel/mis_tickets/` - Mis tickets
  - `POST /api/soporte-panel/crear_ticket_rapido/` - Crear ticket

### **4. Detalle de Ticket** (`/soporte/ticket/{id}`)
- **APIs necesarias:**
  - `GET /api/tickets/{id}/` - Detalle completo
  - `POST /api/ticket-messages/` - Enviar mensaje
  - `POST /api/tickets/{id}/close/` - Cerrar ticket

### **5. Mis Reservas** (`/mis-reservas`)
- **APIs necesarias:**
  - `GET /api/perfil/mis_reservas/` - Lista reservas
  - `GET /api/reservas/{id}/` - Detalle reserva específica

---

## 🎨 **Estructura de Routing Frontend Sugerida**

### **React Router / Next.js**
```javascript
const routes = [
    {
        path: '/dashboard',
        component: 'Dashboard',
        apis: ['/api/perfil/mi_perfil/', '/api/soporte-panel/']
    },
    {
        path: '/perfil',
        component: 'MiPerfil',
        apis: ['/api/perfil/mi_perfil/', '/api/perfil/mis_reservas/']
    },
    {
        path: '/soporte',
        component: 'CentroSoporte',
        apis: ['/api/soporte-panel/', '/api/soporte-panel/mis_tickets/']
    },
    {
        path: '/soporte/ticket/:id',
        component: 'DetalleTicket',
        apis: ['/api/tickets/:id/', '/api/ticket-messages/']
    }
];
```

### **Vue Router**
```javascript
const routes = [
    {
        path: '/dashboard',
        name: 'Dashboard',
        component: Dashboard,
        meta: { requiresAuth: true, apis: ['/api/perfil/mi_perfil/'] }
    },
    {
        path: '/perfil',
        name: 'MiPerfil', 
        component: MiPerfil,
        meta: { requiresAuth: true, apis: ['/api/perfil/mi_perfil/'] }
    },
    {
        path: '/soporte',
        name: 'Soporte',
        component: CentroSoporte,
        meta: { requiresAuth: true, apis: ['/api/soporte-panel/'] }
    }
];
```

### **Angular Routes**
```typescript
const routes: Routes = [
    {
        path: 'dashboard',
        component: DashboardComponent,
        canActivate: [AuthGuard],
        data: { apis: ['/api/perfil/mi_perfil/', '/api/soporte-panel/'] }
    },
    {
        path: 'perfil',
        component: PerfilComponent,
        canActivate: [AuthGuard],
        data: { apis: ['/api/perfil/mi_perfil/'] }
    },
    {
        path: 'soporte',
        component: SoporteComponent,
        canActivate: [AuthGuard],
        data: { apis: ['/api/soporte-panel/'] }
    }
];
```

---

## 🔧 **Headers Estándar**

### **Todas las requests autenticadas:**
```javascript
const headers = {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
};
```

### **Para requests POST/PUT:**
```javascript
const config = {
    method: 'POST', // o PUT
    headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
    },
    body: JSON.stringify(data)
};
```

---

## 🎯 **Prioridades de Implementación**

### **Fase 1 - Básico:**
1. `GET /api/perfil/mi_perfil/` - Perfil usuario
2. `GET /api/soporte-panel/` - Panel soporte básico
3. `POST /api/soporte-panel/crear_ticket_rapido/` - Crear tickets

### **Fase 2 - Intermedio:**
4. `GET /api/perfil/mis_reservas/` - Historial reservas
5. `GET /api/soporte-panel/mis_tickets/` - Lista tickets
6. `PUT /api/usuarios/{id}/` - Editar perfil

### **Fase 3 - Avanzado:**
7. `GET /api/tickets/{id}/` - Detalle tickets
8. `POST /api/ticket-messages/` - Mensajes tickets
9. `GET /api/soporte-panel/notificaciones_soporte/` - Notificaciones

---

Este mapa proporciona una guía clara de cómo estructurar la navegación del frontend y qué APIs consumir en cada pantalla para una implementación eficiente del sistema de perfiles y soporte.