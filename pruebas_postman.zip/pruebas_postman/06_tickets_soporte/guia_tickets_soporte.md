# 🎫 Sistema de Tickets - Soporte

## 📋 Endpoints Principales

### **Crear Ticket**
```http
POST /tickets/
Content-Type: application/json
Authorization: Bearer {access_token}

{
    "titulo": "Problema con reserva #123",
    "descripcion": "No puedo acceder a mi reserva confirmada para el 15 de enero",
    "prioridad": "Media",
    "categoria": "Reservas"
}
```

### **Listar Tickets (Cliente)**
```http
GET /tickets/
Authorization: Bearer {access_token}
```
*Nota: Los clientes solo ven sus propios tickets*

### **Ver Ticket Específico**  
```http
GET /tickets/1/
Authorization: Bearer {access_token}
```

### **Responder a Ticket**
```http
POST /ticket-messages/
Content-Type: application/json
Authorization: Bearer {access_token}

{
    "ticket": 1,
    "contenido": "Hemos revisado tu reserva y encontramos el problema. Se solucionará en las próximas 2 horas."
}
```

### **Cerrar Ticket**
```http
POST /tickets/1/close/
Authorization: Bearer {access_token}
```

## 🏷️ Estados de Tickets

- `Abierto`: Recién creado
- `En Progreso`: Asignado a agente  
- `Respondido`: Agente respondió
- `Cerrado`: Resuelto

## 📊 Prioridades

- `Baja`: Consultas generales
- `Media`: Problemas no urgentes
- `Alta`: Afecta funcionalidad
- `Crítica`: Sistema no funciona

## 🎯 Categorías Disponibles

- `Reservas`: Problemas con bookings
- `Pagos`: Transacciones
- `Técnico`: Errores del sistema
- `Cuenta`: Perfil de usuario
- `General`: Otras consultas

## 👤 Roles y Permisos

### **Cliente**
- ✅ Crear tickets
- ✅ Ver sus tickets  
- ✅ Responder mensajes
- ❌ Ver tickets de otros

### **Soporte**
- ✅ Ver todos los tickets
- ✅ Responder cualquier ticket
- ✅ Cerrar tickets
- ✅ Asignación automática

---
*Los tickets se asignan automáticamente al personal de soporte disponible.*