# 🎫 API Panel de Soporte - Guía Completa

## 📋 Resumen

API especializada para el sistema de soporte al cliente. Permite a los usuarios crear tickets, ver su historial de soporte, recibir notificaciones y acceder a un panel unificado de gestión de tickets de manera sencilla.

---

## 🔗 Endpoints Principales

### 1. **Panel General de Soporte**

```
GET /api/soporte-panel/
```

**Descripción:** Información general del panel de soporte del usuario

**Headers requeridos:**

```json
{
  "Authorization": "Bearer YOUR_JWT_TOKEN"
}
```

**Respuesta exitosa (200):**

```json
{
  "id": 1,
  "nombre": "Juan Pérez",
  "tickets_total": 5,
  "tickets_abiertos": 2,
  "tickets_cerrados": 3,
  "ultimo_ticket": {
    "id": 12,
    "asunto": "[TECNICO] Error en la aplicación",
    "estado": "Asignado",
    "fecha": "2024-10-12T10:30:00Z"
  },
  "panel_info": {
    "puede_crear_ticket": true,
    "limite_tickets_diarios": 5,
    "tickets_hoy": 1,
    "tipos_soporte": [
      {
        "id": "tecnico",
        "nombre": "Soporte Técnico"
      },
      {
        "id": "reservas",
        "nombre": "Problemas con Reservas"
      },
      {
        "id": "pagos",
        "nombre": "Consultas de Pagos"
      },
      {
        "id": "general",
        "nombre": "Consulta General"
      }
    ]
  }
}
```

---

### 2. **Mis Tickets de Soporte**

```
GET /api/soporte-panel/mis_tickets/
```

**Descripción:** Lista completa de tickets del usuario

**Respuesta exitosa (200):**

```json
{
  "count": 5,
  "tickets": [
    {
      "id": 12,
      "asunto": "[TECNICO] Error en la aplicación",
      "descripcion": "La aplicación se cierra inesperadamente cuando intento...",
      "estado": "Asignado",
      "prioridad": "Media",
      "fecha_creacion": "2024-10-12T10:30:00Z",
      "agente_asignado": "María García",
      "mensajes_count": 3
    },
    {
      "id": 11,
      "asunto": "[RESERVAS] No puedo cancelar mi reserva",
      "descripcion": "Necesito cancelar mi reserva del 15 de noviembre pero...",
      "estado": "Cerrado",
      "prioridad": "Alta",
      "fecha_creacion": "2024-10-10T14:20:00Z",
      "agente_asignado": "Carlos López",
      "mensajes_count": 5
    }
  ]
}
```

---

### 3. **Crear Ticket Rápido**

```
POST /api/soporte-panel/crear_ticket_rapido/
```

**Descripción:** Crear un nuevo ticket de soporte rápidamente

**Body (JSON):**

```json
{
  "asunto": "Problema con pago",
  "descripcion": "No se procesó mi pago correctamente y no recibí confirmación",
  "tipo_soporte": "pagos"
}
```

**Respuesta exitosa (201):**

```json
{
  "id": 13,
  "asunto": "[PAGOS] Problema con pago",
  "estado": "Abierto",
  "mensaje": "Ticket creado exitosamente"
}
```

**Error - Límite alcanzado (429):**

```json
{
  "error": "Has alcanzado el límite diario de tickets (5)"
}
```

---

### 4. **Notificaciones de Soporte**

```
GET /api/soporte-panel/notificaciones_soporte/
```

**Descripción:** Notificaciones relacionadas con soporte (últimos 30 días)

**Respuesta exitosa (200):**

```json
{
  "count": 3,
  "notificaciones": [
    {
      "id": 25,
      "tipo": "ticket_respondido",
      "leida": false,
      "fecha": "2024-10-12T11:45:00Z",
      "datos": {
        "ticket_id": 12,
        "mensaje": "Tu ticket ha sido respondido"
      }
    },
    {
      "id": 24,
      "tipo": "ticket_cerrado",
      "leida": true,
      "fecha": "2024-10-10T16:30:00Z",
      "datos": {
        "ticket_id": 11
      }
    }
  ]
}
```

---

## 🎯 Endpoints de Tickets Completos

### **Gestión Completa de Tickets**

Para funcionalidades avanzadas, usar los endpoints principales:

```
GET    /api/tickets/              # Lista todos los tickets del usuario
POST   /api/tickets/              # Crear ticket completo
GET    /api/tickets/{id}/         # Detalle de ticket específico
POST   /api/tickets/{id}/close/   # Cerrar ticket
```

```
GET    /api/ticket-messages/      # Mensajes de tickets
POST   /api/ticket-messages/      # Enviar mensaje a ticket
```

---

## 🚀 Implementación Frontend

### **React/Next.js - Panel de Soporte**

```javascript
// Servicio de Soporte
const SoporteService = {
  async getPanelInfo() {
    const response = await fetch("/api/soporte-panel/", {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
        "Content-Type": "application/json",
      },
    });
    return response.json();
  },

  async getMisTickets() {
    const response = await fetch("/api/soporte-panel/mis_tickets/", {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
    });
    return response.json();
  },

  async crearTicketRapido(ticketData) {
    const response = await fetch("/api/soporte-panel/crear_ticket_rapido/", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(ticketData),
    });

    if (response.status === 429) {
      throw new Error("Límite diario de tickets alcanzado");
    }

    return response.json();
  },
};

// Componente Panel Soporte
function PanelSoporte() {
  const [panelInfo, setPanelInfo] = useState(null);
  const [tickets, setTickets] = useState([]);
  const [showCrearTicket, setShowCrearTicket] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const cargarDatos = async () => {
      try {
        const [panel, ticketsData] = await Promise.all([
          SoporteService.getPanelInfo(),
          SoporteService.getMisTickets(),
        ]);

        setPanelInfo(panel);
        setTickets(ticketsData.tickets);
      } catch (error) {
        console.error("Error:", error);
      } finally {
        setLoading(false);
      }
    };

    cargarDatos();
  }, []);

  const crearTicket = async (formData) => {
    try {
      await SoporteService.crearTicketRapido(formData);
      // Recargar datos
      const ticketsData = await SoporteService.getMisTickets();
      setTickets(ticketsData.tickets);
      setShowCrearTicket(false);
    } catch (error) {
      alert(error.message);
    }
  };

  if (loading) return <div>Cargando panel de soporte...</div>;

  return (
    <div className="panel-soporte">
      {/* Header del Panel */}
      <div className="soporte-header">
        <h1>Centro de Soporte</h1>
        <button
          onClick={() => setShowCrearTicket(true)}
          disabled={
            panelInfo.panel_info.tickets_hoy >=
            panelInfo.panel_info.limite_tickets_diarios
          }
          className="btn-crear-ticket"
        >
          Crear Ticket
        </button>
      </div>

      {/* Estadísticas */}
      <div className="soporte-stats">
        <div className="stat-card">
          <h3>{panelInfo.tickets_total}</h3>
          <p>Total Tickets</p>
        </div>
        <div className="stat-card active">
          <h3>{panelInfo.tickets_abiertos}</h3>
          <p>Tickets Abiertos</p>
        </div>
        <div className="stat-card">
          <h3>{panelInfo.tickets_cerrados}</h3>
          <p>Tickets Cerrados</p>
        </div>
        <div className="stat-card warning">
          <h3>
            {panelInfo.panel_info.tickets_hoy}/
            {panelInfo.panel_info.limite_tickets_diarios}
          </h3>
          <p>Tickets Hoy</p>
        </div>
      </div>

      {/* Lista de Tickets */}
      <div className="tickets-lista">
        <h2>Mis Tickets</h2>
        {tickets.map((ticket) => (
          <div
            key={ticket.id}
            className={`ticket-card ${ticket.estado.toLowerCase()}`}
          >
            <div className="ticket-header">
              <h3>
                #{ticket.id} - {ticket.asunto}
              </h3>
              <span className={`estado ${ticket.estado.toLowerCase()}`}>
                {ticket.estado}
              </span>
            </div>
            <p className="descripcion">{ticket.descripcion}</p>
            <div className="ticket-footer">
              <span>Agente: {ticket.agente_asignado || "Sin asignar"}</span>
              <span>{ticket.mensajes_count} mensajes</span>
              <span>
                {new Date(ticket.fecha_creacion).toLocaleDateString()}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Modal Crear Ticket */}
      {showCrearTicket && (
        <ModalCrearTicket
          tipos={panelInfo.panel_info.tipos_soporte}
          onCrear={crearTicket}
          onCerrar={() => setShowCrearTicket(false)}
        />
      )}
    </div>
  );
}

// Componente Modal Crear Ticket
function ModalCrearTicket({ tipos, onCrear, onCerrar }) {
  const [formData, setFormData] = useState({
    asunto: "",
    descripcion: "",
    tipo_soporte: "general",
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (formData.asunto && formData.descripcion) {
      onCrear(formData);
    }
  };

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <h2>Crear Nuevo Ticket</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Tipo de Soporte:</label>
            <select
              value={formData.tipo_soporte}
              onChange={(e) =>
                setFormData({ ...formData, tipo_soporte: e.target.value })
              }
            >
              {tipos.map((tipo) => (
                <option key={tipo.id} value={tipo.id}>
                  {tipo.nombre}
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label>Asunto:</label>
            <input
              type="text"
              value={formData.asunto}
              onChange={(e) =>
                setFormData({ ...formData, asunto: e.target.value })
              }
              placeholder="Describe brevemente tu problema"
              required
            />
          </div>

          <div className="form-group">
            <label>Descripción:</label>
            <textarea
              value={formData.descripcion}
              onChange={(e) =>
                setFormData({ ...formData, descripcion: e.target.value })
              }
              placeholder="Describe detalladamente tu problema"
              rows="5"
              required
            />
          </div>

          <div className="modal-buttons">
            <button type="button" onClick={onCerrar}>
              Cancelar
            </button>
            <button type="submit">Crear Ticket</button>
          </div>
        </form>
      </div>
    </div>
  );
}
```

### **Vue.js - Panel de Soporte**

```vue
<template>
  <div class="panel-soporte" v-if="!loading">
    <!-- Header -->
    <div class="soporte-header">
      <h1>Centro de Soporte</h1>
      <button
        @click="mostrarCrearTicket = true"
        :disabled="
          panelInfo.panel_info.tickets_hoy >=
          panelInfo.panel_info.limite_tickets_diarios
        "
        class="btn-crear-ticket"
      >
        Crear Ticket
      </button>
    </div>

    <!-- Estadísticas -->
    <div class="soporte-stats">
      <div class="stat-card">
        <h3>{{ panelInfo.tickets_total }}</h3>
        <p>Total Tickets</p>
      </div>
      <div class="stat-card active">
        <h3>{{ panelInfo.tickets_abiertos }}</h3>
        <p>Tickets Abiertos</p>
      </div>
      <div class="stat-card">
        <h3>{{ panelInfo.tickets_cerrados }}</h3>
        <p>Tickets Cerrados</p>
      </div>
      <div class="stat-card warning">
        <h3>
          {{ panelInfo.panel_info.tickets_hoy }}/{{
            panelInfo.panel_info.limite_tickets_diarios
          }}
        </h3>
        <p>Tickets Hoy</p>
      </div>
    </div>

    <!-- Lista Tickets -->
    <div class="tickets-lista">
      <h2>Mis Tickets</h2>
      <div
        v-for="ticket in tickets"
        :key="ticket.id"
        :class="`ticket-card ${ticket.estado.toLowerCase()}`"
      >
        <div class="ticket-header">
          <h3>#{{ ticket.id }} - {{ ticket.asunto }}</h3>
          <span :class="`estado ${ticket.estado.toLowerCase()}`">
            {{ ticket.estado }}
          </span>
        </div>
        <p class="descripcion">{{ ticket.descripcion }}</p>
        <div class="ticket-footer">
          <span>Agente: {{ ticket.agente_asignado || "Sin asignar" }}</span>
          <span>{{ ticket.mensajes_count }} mensajes</span>
          <span>{{ formatearFecha(ticket.fecha_creacion) }}</span>
        </div>
      </div>
    </div>

    <!-- Modal Crear Ticket -->
    <div v-if="mostrarCrearTicket" class="modal-overlay">
      <div class="modal-content">
        <h2>Crear Nuevo Ticket</h2>
        <form @submit.prevent="crearTicket">
          <div class="form-group">
            <label>Tipo de Soporte:</label>
            <select v-model="formTicket.tipo_soporte">
              <option
                v-for="tipo in panelInfo.panel_info.tipos_soporte"
                :key="tipo.id"
                :value="tipo.id"
              >
                {{ tipo.nombre }}
              </option>
            </select>
          </div>

          <div class="form-group">
            <label>Asunto:</label>
            <input
              v-model="formTicket.asunto"
              type="text"
              placeholder="Describe brevemente tu problema"
              required
            />
          </div>

          <div class="form-group">
            <label>Descripción:</label>
            <textarea
              v-model="formTicket.descripcion"
              placeholder="Describe detalladamente tu problema"
              rows="5"
              required
            />
          </div>

          <div class="modal-buttons">
            <button type="button" @click="mostrarCrearTicket = false">
              Cancelar
            </button>
            <button type="submit">Crear Ticket</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, onMounted } from "vue";
import axios from "axios";

export default {
  name: "PanelSoporte",
  setup() {
    const panelInfo = ref(null);
    const tickets = ref([]);
    const loading = ref(true);
    const mostrarCrearTicket = ref(false);
    const formTicket = ref({
      asunto: "",
      descripcion: "",
      tipo_soporte: "general",
    });

    const getHeaders = () => ({
      Authorization: `Bearer ${localStorage.getItem("token")}`,
      "Content-Type": "application/json",
    });

    const cargarDatos = async () => {
      try {
        const [panelRes, ticketsRes] = await Promise.all([
          axios.get("/api/soporte-panel/", { headers: getHeaders() }),
          axios.get("/api/soporte-panel/mis_tickets/", {
            headers: getHeaders(),
          }),
        ]);

        panelInfo.value = panelRes.data;
        tickets.value = ticketsRes.data.tickets;
      } catch (error) {
        console.error("Error:", error);
      } finally {
        loading.value = false;
      }
    };

    const crearTicket = async () => {
      try {
        await axios.post(
          "/api/soporte-panel/crear_ticket_rapido/",
          formTicket.value,
          { headers: getHeaders() }
        );

        // Recargar tickets
        const ticketsRes = await axios.get("/api/soporte-panel/mis_tickets/", {
          headers: getHeaders(),
        });
        tickets.value = ticketsRes.data.tickets;
        mostrarCrearTicket.value = false;

        // Limpiar formulario
        formTicket.value = {
          asunto: "",
          descripcion: "",
          tipo_soporte: "general",
        };
      } catch (error) {
        if (error.response?.status === 429) {
          alert("Has alcanzado el límite diario de tickets");
        } else {
          console.error("Error:", error);
        }
      }
    };

    const formatearFecha = (fecha) => {
      return new Date(fecha).toLocaleDateString();
    };

    onMounted(() => {
      cargarDatos();
    });

    return {
      panelInfo,
      tickets,
      loading,
      mostrarCrearTicket,
      formTicket,
      crearTicket,
      formatearFecha,
    };
  },
};
</script>
```

### **CSS Básico para Estilos**

```css
/* Panel de Soporte Styles */
.panel-soporte {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.soporte-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 30px;
}

.btn-crear-ticket {
  background: #007bff;
  color: white;
  padding: 12px 24px;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: 16px;
}

.btn-crear-ticket:disabled {
  background: #ccc;
  cursor: not-allowed;
}

.soporte-stats {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 20px;
  margin-bottom: 30px;
}

.stat-card {
  background: white;
  padding: 24px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  text-align: center;
}

.stat-card.active {
  border-left: 4px solid #28a745;
}

.stat-card.warning {
  border-left: 4px solid #ffc107;
}

.stat-card h3 {
  font-size: 2em;
  margin: 0 0 8px 0;
  color: #333;
}

.ticket-card {
  background: white;
  padding: 20px;
  margin-bottom: 16px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  border-left: 4px solid #ddd;
}

.ticket-card.abierto {
  border-left-color: #007bff;
}

.ticket-card.asignado {
  border-left-color: #ffc107;
}

.ticket-card.cerrado {
  border-left-color: #28a745;
}

.ticket-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}

.estado {
  padding: 4px 12px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: bold;
}

.estado.abierto {
  background: #e3f2fd;
  color: #1976d2;
}

.estado.asignado {
  background: #fff3e0;
  color: #f57c00;
}

.estado.cerrado {
  background: #e8f5e8;
  color: #388e3c;
}

.ticket-footer {
  display: flex;
  gap: 20px;
  font-size: 14px;
  color: #666;
  margin-top: 12px;
}

/* Modal Styles */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background: white;
  padding: 30px;
  border-radius: 8px;
  width: 90%;
  max-width: 500px;
}

.form-group {
  margin-bottom: 20px;
}

.form-group label {
  display: block;
  margin-bottom: 8px;
  font-weight: bold;
}

.form-group input,
.form-group select,
.form-group textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 14px;
}

.modal-buttons {
  display: flex;
  gap: 12px;
  justify-content: flex-end;
}

.modal-buttons button {
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.modal-buttons button[type="submit"] {
  background: #007bff;
  color: white;
}

.modal-buttons button[type="button"] {
  background: #6c757d;
  color: white;
}
```

---

## 🔄 Flujo de Usuario - Soporte

### **1. Acceso al Panel**

```
Usuario autenticado → GET /api/soporte-panel/
↓
Mostrar estadísticas y estado general
```

### **2. Ver Tickets Existentes**

```
Panel cargado → GET /api/soporte-panel/mis_tickets/
↓
Lista de tickets con estados y detalles
```

### **3. Crear Nuevo Ticket**

```
Click "Crear Ticket" → Formulario modal
↓
POST /api/soporte-panel/crear_ticket_rapido/
↓
Recargar lista de tickets
```

### **4. Gestión Avanzada**

```
Panel básico → Redirigir a /api/tickets/ endpoints
↓
CRUD completo de tickets y mensajes
```

---

## ⚡ Límites y Validaciones

### **Límites Diarios**

- **5 tickets por día** por usuario
- Previene spam de tickets
- Error 429 si se excede el límite

### **Tipos de Soporte**

- **Técnico:** Problemas de la aplicación
- **Reservas:** Consultas sobre reservas
- **Pagos:** Problemas de pagos
- **General:** Consultas generales

### **Estados de Tickets**

- **Abierto:** Recién creado
- **Asignado:** Asignado a un agente
- **Respondido:** El agente ha respondido
- **Cerrado:** Ticket resuelto

---

## 🎯 Casos de Uso

### **Dashboard de Soporte**

- Panel principal con estadísticas
- Acceso rápido a funciones más usadas
- Vista general del estado del soporte

### **Gestión de Tickets**

- Crear tickets rápidamente
- Ver historial completo
- Seguimiento de estados

### **Notificaciones**

- Alertas de respuestas de agentes
- Notificaciones de cambios de estado
- Historial de interacciones

---

Esta API proporciona una interfaz completa y fácil de usar para que los clientes gestionen su soporte, con funcionalidades básicas centralizadas y acceso a funciones avanzadas cuando sea necesario.
