#!/usr/bin/env python
"""
Script para crear paquetes turísticos de ejemplo
Ejecutar desde la raíz del proyecto: python scripts/crear_paquetes_ejemplo.py
"""
import os
import sys
import django
from datetime import date, time, timedelta

# Configurar Django
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()

from condominio.models import Servicio, Paquete, PaqueteServicio, Categoria

def crear_paquetes_ejemplo():
    """Crear paquetes turísticos de ejemplo usando servicios existentes"""
    
    print("🚀 Iniciando creación de paquetes turísticos de ejemplo...")
    
    # Verificar servicios existentes
    servicios = Servicio.objects.all()
    print(f"📋 Servicios disponibles: {servicios.count()}")
    
    for servicio in servicios:
        print(f"  - {servicio.titulo} (${servicio.precio_usd})")
    
    if servicios.count() < 2:
        print("⚠️  Necesitas al menos 2 servicios para crear paquetes. Creando servicios básicos...")
        crear_servicios_basicos()
        servicios = Servicio.objects.all()
    
    # 📦 PAQUETE 1: Full Tour Bolivia (Salar de Uyuni + Isla del Sol + Tiwanaku)
    print("\n🎯 Creando Paquete: Full Tour Bolivia...")
    
    paquete_full = Paquete.objects.create(
        nombre="Full Tour Bolivia - Experiencia Completa",
        descripcion="El paquete más completo para conocer los principales atractivos turísticos de Bolivia. Incluye el majestuoso Salar de Uyuni, la mística Isla del Sol en el Lago Titicaca y las ruinas arqueológicas de Tiwanaku.",
        duracion="5 días, 4 noches",
        precio_base=850.00,
        precio_bob=5865.00,  # Aproximadamente 6.9 BOB por USD
        cupos_disponibles=20,
        cupos_ocupados=0,
        fecha_inicio=date.today(),
        fecha_fin=date.today() + timedelta(days=90),
        estado='Activo',
        destacado=True,
        imagen_principal="https://example.com/full-tour-bolivia.jpg",
        punto_salida="Plaza Murillo, La Paz",
        incluye=[
            "Transporte terrestre y aéreo",
            "Alojamiento en hoteles 3 estrellas",
            "Desayuno, almuerzo y cena",
            "Guía turístico especializado",
            "Entradas a todos los sitios",
            "Seguro de viaje"
        ],
        no_incluye=[
            "Gastos personales",
            "Bebidas alcohólicas",
            "Propinas",
            "Actividades opcionales no mencionadas"
        ]
    )
    
    # Asignar servicios al paquete
    servicios_full = servicios.filter(titulo__icontains='Salar de Uyuni') | servicios.filter(titulo__icontains='Isla del Sol') | servicios.filter(titulo__icontains='Tiwanaku')
    
    if servicios_full.exists():
        for i, servicio in enumerate(servicios_full, 1):
            PaqueteServicio.objects.create(
                paquete=paquete_full,
                servicio=servicio,
                dia=i,
                orden=1,
                hora_inicio=time(8, 0),
                hora_fin=time(18, 0),
                notas=f"Día {i}: {servicio.titulo}"
            )
    else:
        # Usar los primeros 3 servicios disponibles
        for i, servicio in enumerate(servicios[:3], 1):
            PaqueteServicio.objects.create(
                paquete=paquete_full,
                servicio=servicio,
                dia=i,
                orden=1,
                hora_inicio=time(8, 0),
                hora_fin=time(18, 0),
                notas=f"Día {i}: {servicio.titulo}"
            )
    
    print(f"✅ Paquete 'Full Tour Bolivia' creado con ID: {paquete_full.pk}")
    
    # 📦 PAQUETE 2: Aventura Andina (2 días)
    print("\n🎯 Creando Paquete: Aventura Andina...")
    
    paquete_aventura = Paquete.objects.create(
        nombre="Aventura Andina - Escapada de Fin de Semana",
        descripcion="Perfecto para una escapada de fin de semana. Descubre los paisajes más impresionantes de los Andes bolivianos en una experiencia intensa de 2 días.",
        duracion="2 días, 1 noche",
        precio_base=350.00,
        precio_bob=2415.00,
        cupos_disponibles=15,
        cupos_ocupados=3,
        fecha_inicio=date.today(),
        fecha_fin=date.today() + timedelta(days=60),
        estado='Activo',
        destacado=True,
        imagen_principal="https://example.com/aventura-andina.jpg",
        punto_salida="Terminal de Buses, La Paz",
        incluye=[
            "Transporte turístico",
            "Alojamiento en ecolodge",
            "Todas las comidas",
            "Guía bilingüe",
            "Actividades incluidas"
        ],
        no_incluye=[
            "Seguro personal",
            "Gastos extras",
            "Bebidas"
        ]
    )
    
    # Asignar servicios (primeros 2 disponibles)
    for i, servicio in enumerate(servicios[:2], 1):
        PaqueteServicio.objects.create(
            paquete=paquete_aventura,
            servicio=servicio,
            dia=i,
            orden=1,
            hora_inicio=time(7, 30),
            hora_fin=time(19, 0),
            notas=f"Día {i}: Aventura en {servicio.titulo}"
        )
    
    print(f"✅ Paquete 'Aventura Andina' creado con ID: {paquete_aventura.pk}")
    
    # 📦 PAQUETE 3: Descubrimiento Cultural (1 día)
    print("\n🎯 Creando Paquete: Descubrimiento Cultural...")
    
    paquete_cultural = Paquete.objects.create(
        nombre="Descubrimiento Cultural - Tour de 1 Día",
        descripcion="Un día completo para conocer la riqueza cultural e histórica de Bolivia. Ideal para viajeros con tiempo limitado que quieren una experiencia auténtica.",
        duracion="1 día",
        precio_base=120.00,
        precio_bob=828.00,
        cupos_disponibles=25,
        cupos_ocupados=8,
        fecha_inicio=date.today(),
        fecha_fin=date.today() + timedelta(days=30),
        estado='Activo',
        destacado=False,
        imagen_principal="https://example.com/cultural-tour.jpg",
        punto_salida="Hotel Plaza, Centro La Paz",
        incluye=[
            "Transporte local",
            "Guía especializado en historia",
            "Almuerzo típico",
            "Entradas a museos",
            "Refrigerio"
        ],
        no_incluye=[
            "Transporte al punto de encuentro",
            "Cena",
            "Compras personales"
        ]
    )
    
    # Asignar 1 servicio
    if servicios.exists():
        servicio = servicios.first()
        PaqueteServicio.objects.create(
            paquete=paquete_cultural,
            servicio=servicio,
            dia=1,
            orden=1,
            hora_inicio=time(9, 0),
            hora_fin=time(17, 0),
            notas="Tour cultural completo con almuerzo incluido",
            punto_encuentro_override="Plaza San Francisco, La Paz"
        )
    
    print(f"✅ Paquete 'Descubrimiento Cultural' creado con ID: {paquete_cultural.pk}")
    
    # Resumen
    paquetes_creados = Paquete.objects.all()
    print(f"\n🎉 ¡Proceso completado!")
    print(f"📊 Total de paquetes creados: {paquetes_creados.count()}")
    print("\n📋 Resumen de paquetes:")
    
    for paquete in paquetes_creados:
        servicios_count = paquete.servicios.count()
        print(f"  🎯 {paquete.nombre}")
        print(f"     💰 Precio: ${paquete.precio_base}")
        print(f"     ⏱️  Duración: {paquete.duracion}")
        print(f"     🎫 Cupos: {paquete.cupos_restantes}/{paquete.cupos_disponibles} disponibles")
        print(f"     📦 Servicios incluidos: {servicios_count}")
        print(f"     ⭐ Destacado: {'Sí' if paquete.destacado else 'No'}")
        print(f"     🔗 API URL: /api/paquetes/{paquete.pk}/")
        print("")


def crear_servicios_basicos():
    """Crear servicios básicos si no existen"""
    print("🔧 Creando servicios básicos...")
    
    # Crear categoría si no existe
    categoria, created = Categoria.objects.get_or_create(
        nombre="Tours",
        defaults={'descripcion': 'Tours turísticos generales'}
    )
    
    servicios_basicos = [
        {
            'titulo': 'Tour Salar de Uyuni',
            'descripcion': 'Experiencia única en el salar más grande del mundo con paisajes espectaculares',
            'duracion': '1 día',
            'capacidad_max': 8,
            'punto_encuentro': 'Uyuni, Potosí',
            'precio_usd': 280.00,
            'servicios_incluidos': ['Transporte 4x4', 'Almuerzo', 'Guía especializado']
        },
        {
            'titulo': 'Tour Isla del Sol',
            'descripcion': 'Descubre la cuna del Imperio Inca en el místico Lago Titicaca',
            'duracion': '1 día',
            'capacidad_max': 15,
            'punto_encuentro': 'Copacabana, La Paz',
            'precio_usd': 150.00,
            'servicios_incluidos': ['Transporte lacustre', 'Guía', 'Entrada arqueológica']
        },
        {
            'titulo': 'Tour Ruinas de Tiwanaku',
            'descripcion': 'Explora las ruinas de una de las civilizaciones más antiguas de América',
            'duracion': '1 día',
            'capacidad_max': 20,
            'punto_encuentro': 'La Paz, Plaza Murillo',
            'precio_usd': 120.00,
            'servicios_incluidos': ['Transporte', 'Guía arqueológico', 'Entrada al sitio']
        }
    ]
    
    for servicio_data in servicios_basicos:
        servicio, created = Servicio.objects.get_or_create(
            titulo=servicio_data['titulo'],
            defaults={
                **servicio_data,
                'categoria': categoria,
                'estado': 'Activo',
                'imagen_url': f"https://example.com/{servicio_data['titulo'].lower().replace(' ', '-')}.jpg"
            }
        )
        if created:
            print(f"  ✅ Servicio creado: {servicio.titulo}")
        else:
            print(f"  ℹ️  Servicio ya existe: {servicio.titulo}")


if __name__ == '__main__':
    crear_paquetes_ejemplo()