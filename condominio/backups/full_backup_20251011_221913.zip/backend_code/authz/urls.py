
from django.urls import path
from . import views

urlpatterns = [
    path('login/',views.login),
    path('register/',views.register),
    path('perfil/',views.perfil),
    path('logout/', views.logout),
]