# Script to create a test user, perfil (Usuario), Rol and Token
import os
import django
from django.conf import settings
from datetime import date, datetime

proj_root = os.path.dirname(os.path.dirname(__file__))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')

# Asegurar que el proyecto está en sys.path para poder importar settings
import sys
if proj_root not in sys.path:
    sys.path.insert(0, proj_root)

django.setup()

from django.contrib.auth.models import User
from authz.models import Rol
from condominio.models import Usuario
from rest_framework.authtoken.models import Token

# Create or get rol
rol, _ = Rol.objects.get_or_create(nombre='cliente')

# Create or get user
username = 'test_real'
email = 'test_real@example.com'
password = 'testpass123'
user, created = User.objects.get_or_create(username=username, defaults={'email': email})
if created:
    user.set_password(password)
    user.save()

perfil, pcreated = Usuario.objects.get_or_create(user=user, defaults={'nombre': 'Test Real', 'rol': rol})
if not pcreated:
    perfil.rol = rol
    perfil.nombre = 'Test Real'
    perfil.save()

# Create token
token, _ = Token.objects.get_or_create(user=user)
print('TOKEN='+token.key)
print('USER_ID='+str(user.id))
print('PERFIL_ID='+str(perfil.id))
print('PAQUETE_NOTE: create a Paquete via admin or API if none exists')

# Crear un paquete de prueba si no existe
from condominio.models import Paquete
if not Paquete.objects.exists():
    p = Paquete.objects.create(
        nombre='PaquetePruebaScript',
        descripcion='Creado por script de pruebas',
        duracion='1D',
        precio_base=50.00,
        precio_bob=350.00,
        cupos_disponibles=10,
        cupos_ocupados=0,
        fecha_inicio=date.today(),
        fecha_fin=date.today(),
        punto_salida='Plaza Principal',
    )
    print('PAQUETE_CREATED_ID='+str(p.id))
else:
    first = Paquete.objects.first()
    print('PAQUETE_EXISTS_ID='+str(first.id))
