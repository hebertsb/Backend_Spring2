import os
import django
import sys
# Ensure the project root is on sys.path so we can import the Django settings module
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

# Ensure the settings module is loaded
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
try:
    django.setup()
except Exception as e:
    print('DJANGO SETUP ERROR', e)
    sys.exit(1)

from django.contrib.auth.models import User

email = 'admin@prueba.com'
passwd = 'temporal123'

try:
    u = User.objects.get(email=email)
    print('FOUND', u.id, 'username=', u.username, 'email=', u.email, 'is_active=', u.is_active)
    print('check_password_result=', u.check_password(passwd))
    # list tokens if rest_framework.authtoken present
    try:
        from rest_framework.authtoken.models import Token
        toks = list(Token.objects.filter(user=u).values_list('key', flat=True))
        print('tokens=', toks)
    except Exception:
        print('Token model not available or error listing tokens')
except User.DoesNotExist:
    print('NOT FOUND')
except Exception as e:
    print('ERROR', e)
